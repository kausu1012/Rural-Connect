import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { checkDatabaseConnection, initializeDatabase, runMigrations } from "./db";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Configure request logging
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  try {
    // Initialize database connection
    log("Initializing database connection...");
    const connected = await checkDatabaseConnection();
    
    if (connected) {
      // Run database migrations and initialize data if needed
      await runMigrations();
      await initializeDatabase();
      log("Database initialized successfully");
    } else {
      log("Database connection failed, using fallback storage", "db");
    }
  } catch (error) {
    log(`Database initialization error: ${error}`, "db");
    log("Continuing with fallback storage mechanism", "db");
  }

  // Register API routes
  const server = await registerRoutes(app);

  // Global error handler
  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    log(`Error: ${err.message}`, "error");
    res.status(status).json({ message });
  });

  // Setup Vite in development mode
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // Start the server
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`Rural Travel Assistance platform running on port ${port}`);
    log(`Database: ${process.env.DATABASE_URL ? 'PostgreSQL' : 'In-memory storage'}`);
  });
})().catch(err => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
