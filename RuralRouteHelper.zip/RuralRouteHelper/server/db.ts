import { drizzle } from 'drizzle-orm/node-postgres';
import { migrate } from 'drizzle-orm/node-postgres/migrator';
import { Pool } from 'pg';
import * as schema from '../shared/schema';
import { log } from './vite';

// Create a PostgreSQL pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Create a Drizzle ORM instance
export const db = drizzle(pool, { schema });

// Function to run migrations
export async function runMigrations() {
  try {
    log('Running database migrations...', 'db');
    // This will automatically run needed migrations on the database
    await migrate(db, { migrationsFolder: 'migrations' });
    log('Database migrations completed successfully', 'db');
  } catch (error) {
    log(`Database migration error: ${error}`, 'db');
    throw error;
  }
}

// Function to check database connection and schema existence
export async function checkDatabaseConnection(): Promise<boolean> {
  try {
    // Simple query to check if database is accessible
    const result = await pool.query('SELECT NOW() as current_time');
    if (result.rows.length > 0) {
      log('Database connection successful', 'db');
      return true;
    }
    return false;
  } catch (error) {
    log(`Database connection error: ${error}`, 'db');
    return false;
  }
}

// Initialize database tables and seed data if needed
export async function initializeDatabase() {
  try {
    log('Initializing database...', 'db');
    
    // Check if we have any data in the locations table
    const locationCount = await db.select().from(schema.locations).execute();
    
    if (locationCount.length === 0) {
      log('Seeding initial data...', 'db');
      await seedInitialData();
    } else {
      log('Database already contains data, skipping seed operation', 'db');
    }
    
    log('Database initialization completed', 'db');
  } catch (error) {
    log(`Database initialization error: ${error}`, 'db');
    throw error;
  }
}

// Seed initial data for demo purposes
async function seedInitialData() {
  // Inserting rural and urban locations
  const redwoodVillage = await db.insert(schema.locations).values({
    name: 'Redwood Village',
    type: 'rural',
    description: 'A peaceful rural village surrounded by agriculture',
    latitude: 17.4424,
    longitude: 78.3876,
    region: 'Northern',
    district: 'Redwood',
    state: 'Telangana',
    population: 2500,
    amenities: null // Initialize without arrays first
  }).returning().then(res => res[0]);

  const eastportCity = await db.insert(schema.locations).values({
    name: 'Eastport City',
    type: 'urban',
    description: 'A bustling urban center with various amenities',
    latitude: 17.3616,
    longitude: 78.4747,
    region: 'Eastern',
    district: 'Eastport',
    state: 'Telangana',
    population: 120000,
    amenities: null
  }).returning().then(res => res[0]);

  const hillcrest = await db.insert(schema.locations).values({
    name: 'Hillcrest',
    type: 'rural',
    description: 'A small village in the hills with scenic beauty',
    latitude: 17.5045,
    longitude: 78.3012,
    region: 'Western',
    district: 'Hillcrest',
    state: 'Telangana',
    population: 1800,
    amenities: null
  }).returning().then(res => res[0]);

  const centralStation = await db.insert(schema.locations).values({
    name: 'Central Station',
    type: 'urban',
    description: 'Major transport hub connecting multiple routes',
    latitude: 17.4344,
    longitude: 78.5014,
    region: 'Central',
    district: 'Central',
    state: 'Telangana',
    population: 85000,
    amenities: null
  }).returning().then(res => res[0]);
  
  // Inserting transport options
  const busTransport = await db.insert(schema.transportOptions).values({
    name: 'Public Transit',
    type: 'bus',
    description: 'Regular bus service connecting rural and urban areas',
    iconName: 'bus',
    features: null,
    capacity: 45,
    accessibility: true,
    costPerKm: '2.5',
    operator: 'State Transport Corporation',
    contactInfo: '+91 1234567890',
  }).returning().then(res => res[0]);
  
  const trainTransport = await db.insert(schema.transportOptions).values({
    name: 'Rail Service',
    type: 'train',
    description: 'Train service for longer journeys between major stations',
    iconName: 'train',
    features: null,
    capacity: 500,
    accessibility: true,
    costPerKm: '1.8',
    operator: 'Indian Railways',
    contactInfo: '+91 9876543210',
  }).returning().then(res => res[0]);
  
  const onDemandService = await db.insert(schema.transportOptions).values({
    name: 'On-Demand Services',
    type: 'car',
    description: 'Book private vehicles for door-to-door service',
    iconName: 'car',
    features: null,
    capacity: 4,
    accessibility: false,
    costPerKm: '12.0',
    operator: 'Regional Cab Services',
    contactInfo: '+91 8765432109',
  }).returning().then(res => res[0]);
  
  // Inserting routes individually to avoid type errors
  await db.insert(schema.routes).values({
    fromLocationId: redwoodVillage.id,
    toLocationId: eastportCity.id,
    transportOptionId: busTransport.id,
    duration: 90, // 1.5 hours
    distance: '45.5', // km
    price: '125.0', // currency
    schedule: '6:00, 9:00, 12:00, 15:00, 18:00',
    frequency: 'Daily',
    isPopular: true,
    isActive: true
  });
  
  await db.insert(schema.routes).values({
    fromLocationId: redwoodVillage.id,
    toLocationId: centralStation.id,
    transportOptionId: onDemandService.id,
    duration: 75, // 1.25 hours
    distance: '38.0', // km
    price: '450.0', // currency
    schedule: 'On-demand',
    frequency: '24/7',
    isPopular: false,
    isActive: true
  });
  
  await db.insert(schema.routes).values({
    fromLocationId: hillcrest.id,
    toLocationId: eastportCity.id,
    transportOptionId: busTransport.id,
    duration: 105, // 1.75 hours
    distance: '52.0', // km
    price: '130.0', // currency
    schedule: '7:30, 10:30, 13:30, 16:30',
    frequency: 'Daily except Sundays',
    isPopular: true,
    isActive: true
  });
  
  await db.insert(schema.routes).values({
    fromLocationId: hillcrest.id,
    toLocationId: centralStation.id,
    transportOptionId: trainTransport.id,
    duration: 60, // 1 hour
    distance: '55.0', // km
    price: '95.0', // currency
    schedule: '5:00, 8:00, 11:00, 14:00, 17:00, 20:00',
    frequency: 'Daily',
    isPopular: true,
    isActive: true
  });
  
  // Inserting travel guides individually to avoid type errors
  await db.insert(schema.travelGuides).values({
    title: 'Rural Transport Tips',
    description: 'Essential information for traveling between rural areas and cities',
    content: 'When traveling from villages to urban centers, it\'s important to plan ahead. Rural buses often have fixed schedules with limited frequency. During monsoon season, some roads may be affected, so check weather conditions before departure. Carrying extra snacks and water is recommended for longer journeys. Many rural buses do not have online booking, so arrive early to secure seats, especially during festivals and holidays.',
    type: 'general',
    highlights: null,
    author: 'Travel Association',
    locationId: null,
    imageUrl: null,
    publishedAt: new Date()
  });
  
  await db.insert(schema.travelGuides).values({
    title: 'Eastport City Guide',
    description: 'Everything you need to know about navigating Eastport City',
    content: 'Eastport City is a major urban center with excellent public transportation options. The city operates bus services from 5 AM to 11 PM daily. For visitors, a day pass is recommended which allows unlimited travel on all city buses. The Central Market area can be congested during evenings, so plan accordingly. The city also offers app-based taxi services which are reliable and convenient for shorter distances.',
    type: 'general',
    highlights: null,
    author: 'City Tourism Board',
    locationId: eastportCity.id,
    imageUrl: null,
    publishedAt: new Date()
  });
  
  await db.insert(schema.travelGuides).values({
    title: 'Festival Season Travel',
    description: 'Special transportation arrangements during major festivals',
    content: 'During major festivals like Diwali and Pongal, transportation services operate on modified schedules. Extra buses are added between popular routes, but they fill up quickly. It\'s advisable to book return tickets at the same time as your departure. Some rural areas may have limited service on actual festival days, so plan to travel a day before or after for better availability. Special night services are often available during this time.',
    type: 'seasonal',
    highlights: null,
    author: 'Travel Expert',
    locationId: null,
    imageUrl: null,
    publishedAt: new Date()
  });
  
  log('Database seeded with initial data', 'db');
}