import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertInquirySchema,
  insertLocationSchema,
  insertRouteSchema,
  insertTransportOptionSchema,
  insertTravelGuideSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // All API routes are prefixed with /api
  
  // Locations endpoints
  app.get("/api/locations", async (req, res) => {
    try {
      const locations = await storage.getLocations();
      res.json(locations);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve locations" });
    }
  });

  app.get("/api/locations/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      const locations = await storage.searchLocations(query);
      res.json(locations);
    } catch (error) {
      res.status(500).json({ message: "Failed to search locations" });
    }
  });

  app.get("/api/locations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const location = await storage.getLocationById(id);
      if (!location) {
        return res.status(404).json({ message: "Location not found" });
      }
      res.json(location);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve location" });
    }
  });

  app.post("/api/locations", async (req, res) => {
    try {
      const validatedData = insertLocationSchema.parse(req.body);
      const location = await storage.createLocation(validatedData);
      res.status(201).json(location);
    } catch (error) {
      res.status(400).json({ message: "Invalid location data" });
    }
  });

  // Transport options endpoints
  app.get("/api/transport-options", async (req, res) => {
    try {
      const options = await storage.getTransportOptions();
      res.json(options);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve transport options" });
    }
  });

  app.get("/api/transport-options/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const option = await storage.getTransportOptionById(id);
      if (!option) {
        return res.status(404).json({ message: "Transport option not found" });
      }
      res.json(option);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve transport option" });
    }
  });

  app.post("/api/transport-options", async (req, res) => {
    try {
      const validatedData = insertTransportOptionSchema.parse(req.body);
      const option = await storage.createTransportOption(validatedData);
      res.status(201).json(option);
    } catch (error) {
      res.status(400).json({ message: "Invalid transport option data" });
    }
  });

  // Routes endpoints
  app.get("/api/routes", async (req, res) => {
    try {
      const routes = await storage.getRoutes();
      res.json(routes);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve routes" });
    }
  });

  app.get("/api/routes/popular", async (req, res) => {
    try {
      const routes = await storage.getPopularRoutes();
      res.json(routes);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve popular routes" });
    }
  });

  app.get("/api/routes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const route = await storage.getRouteById(id);
      if (!route) {
        return res.status(404).json({ message: "Route not found" });
      }
      res.json(route);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve route" });
    }
  });

  app.post("/api/routes", async (req, res) => {
    try {
      const validatedData = insertRouteSchema.parse(req.body);
      const route = await storage.createRoute(validatedData);
      res.status(201).json(route);
    } catch (error) {
      res.status(400).json({ message: "Invalid route data" });
    }
  });

  // Search routes endpoint
  app.get("/api/search-routes", async (req, res) => {
    try {
      const { from, to, date } = req.query;
      
      if (!from || !to || !date) {
        return res.status(400).json({ 
          message: "Missing required parameters. 'from', 'to', and 'date' are required." 
        });
      }

      const routes = await storage.findRoutes(
        from as string, 
        to as string, 
        date as string
      );
      
      res.json(routes);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to search routes", 
        error: (error as Error).message 
      });
    }
  });

  // Travel guides endpoints
  app.get("/api/travel-guides", async (req, res) => {
    try {
      const guides = await storage.getTravelGuides();
      res.json(guides);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve travel guides" });
    }
  });

  app.get("/api/travel-guides/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const guide = await storage.getTravelGuideById(id);
      if (!guide) {
        return res.status(404).json({ message: "Travel guide not found" });
      }
      res.json(guide);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve travel guide" });
    }
  });

  app.get("/api/travel-guides/type/:type", async (req, res) => {
    try {
      const type = req.params.type;
      const guides = await storage.getTravelGuidesByType(type);
      res.json(guides);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve travel guides by type" });
    }
  });

  app.post("/api/travel-guides", async (req, res) => {
    try {
      const validatedData = insertTravelGuideSchema.parse(req.body);
      const guide = await storage.createTravelGuide(validatedData);
      res.status(201).json(guide);
    } catch (error) {
      res.status(400).json({ message: "Invalid travel guide data" });
    }
  });

  // Inquiries endpoints
  app.post("/api/inquiries", async (req, res) => {
    try {
      const validatedData = insertInquirySchema.parse(req.body);
      const inquiry = await storage.createInquiry(validatedData);
      res.status(201).json(inquiry);
    } catch (error) {
      res.status(400).json({ message: "Invalid inquiry data" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
