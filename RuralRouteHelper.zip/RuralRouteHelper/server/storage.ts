import { 
  users, type User, type InsertUser,
  locations, type Location, type InsertLocation,
  transportOptions, type TransportOption, type InsertTransportOption,
  routes, type Route, type InsertRoute,
  travelGuides, type TravelGuide, type InsertTravelGuide,
  inquiries, type Inquiry, type InsertInquiry
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Location operations
  getLocations(): Promise<Location[]>;
  getLocationById(id: number): Promise<Location | undefined>;
  getLocationsByType(type: string): Promise<Location[]>;
  createLocation(location: InsertLocation): Promise<Location>;
  searchLocations(query: string): Promise<Location[]>;

  // Transport options operations
  getTransportOptions(): Promise<TransportOption[]>;
  getTransportOptionById(id: number): Promise<TransportOption | undefined>;
  createTransportOption(transportOption: InsertTransportOption): Promise<TransportOption>;

  // Routes operations
  getRoutes(): Promise<Route[]>;
  getRouteById(id: number): Promise<Route | undefined>;
  getRoutesByFromTo(fromId: number, toId: number): Promise<Route[]>;
  getPopularRoutes(): Promise<Route[]>;
  createRoute(route: InsertRoute): Promise<Route>;
  findRoutes(from: string, to: string, date: string): Promise<any[]>;

  // Travel guides operations
  getTravelGuides(): Promise<TravelGuide[]>;
  getTravelGuideById(id: number): Promise<TravelGuide | undefined>;
  getTravelGuidesByType(type: string): Promise<TravelGuide[]>;
  createTravelGuide(travelGuide: InsertTravelGuide): Promise<TravelGuide>;

  // Inquiry operations
  getInquiries(): Promise<Inquiry[]>;
  createInquiry(inquiry: InsertInquiry): Promise<Inquiry>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private locations: Map<number, Location>;
  private transportOptions: Map<number, TransportOption>;
  private routes: Map<number, Route>;
  private travelGuides: Map<number, TravelGuide>;
  private inquiries: Map<number, Inquiry>;

  private userId: number;
  private locationId: number;
  private transportOptionId: number;
  private routeId: number;
  private travelGuideId: number;
  private inquiryId: number;

  constructor() {
    this.users = new Map();
    this.locations = new Map();
    this.transportOptions = new Map();
    this.routes = new Map();
    this.travelGuides = new Map();
    this.inquiries = new Map();

    this.userId = 1;
    this.locationId = 1;
    this.transportOptionId = 1;
    this.routeId = 1;
    this.travelGuideId = 1;
    this.inquiryId = 1;

    // Initialize with sample data
    this.initializeData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Location methods
  async getLocations(): Promise<Location[]> {
    return Array.from(this.locations.values());
  }

  async getLocationById(id: number): Promise<Location | undefined> {
    return this.locations.get(id);
  }

  async getLocationsByType(type: string): Promise<Location[]> {
    return Array.from(this.locations.values()).filter(
      (location) => location.type === type,
    );
  }

  async createLocation(insertLocation: InsertLocation): Promise<Location> {
    const id = this.locationId++;
    const location: Location = { ...insertLocation, id };
    this.locations.set(id, location);
    return location;
  }

  async searchLocations(query: string): Promise<Location[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.locations.values()).filter(
      (location) => location.name.toLowerCase().includes(lowerQuery),
    );
  }

  // Transport options methods
  async getTransportOptions(): Promise<TransportOption[]> {
    return Array.from(this.transportOptions.values());
  }

  async getTransportOptionById(id: number): Promise<TransportOption | undefined> {
    return this.transportOptions.get(id);
  }

  async createTransportOption(insertTransportOption: InsertTransportOption): Promise<TransportOption> {
    const id = this.transportOptionId++;
    const transportOption: TransportOption = { ...insertTransportOption, id };
    this.transportOptions.set(id, transportOption);
    return transportOption;
  }

  // Routes methods
  async getRoutes(): Promise<Route[]> {
    return Array.from(this.routes.values());
  }

  async getRouteById(id: number): Promise<Route | undefined> {
    return this.routes.get(id);
  }

  async getRoutesByFromTo(fromId: number, toId: number): Promise<Route[]> {
    return Array.from(this.routes.values()).filter(
      (route) => route.fromLocationId === fromId && route.toLocationId === toId,
    );
  }

  async getPopularRoutes(): Promise<Route[]> {
    return Array.from(this.routes.values()).filter(
      (route) => route.isPopular,
    );
  }

  async createRoute(insertRoute: InsertRoute): Promise<Route> {
    const id = this.routeId++;
    const route: Route = { ...insertRoute, id };
    this.routes.set(id, route);
    return route;
  }

  async findRoutes(from: string, to: string, date: string): Promise<any[]> {
    // First, find matching locations
    const fromLocations = await this.searchLocations(from);
    const toLocations = await this.searchLocations(to);
    
    const results = [];
    
    // For each possible from-to pair, find routes
    for (const fromLocation of fromLocations) {
      for (const toLocation of toLocations) {
        const routes = await this.getRoutesByFromTo(fromLocation.id, toLocation.id);
        
        for (const route of routes) {
          const transportOption = await this.getTransportOptionById(route.transportOptionId);
          
          if (transportOption) {
            results.push({
              route,
              fromLocation,
              toLocation,
              transportOption,
              date
            });
          }
        }
      }
    }
    
    return results;
  }

  // Travel guides methods
  async getTravelGuides(): Promise<TravelGuide[]> {
    return Array.from(this.travelGuides.values());
  }

  async getTravelGuideById(id: number): Promise<TravelGuide | undefined> {
    return this.travelGuides.get(id);
  }

  async getTravelGuidesByType(type: string): Promise<TravelGuide[]> {
    return Array.from(this.travelGuides.values()).filter(
      (guide) => guide.type === type,
    );
  }

  async createTravelGuide(insertTravelGuide: InsertTravelGuide): Promise<TravelGuide> {
    const id = this.travelGuideId++;
    const travelGuide: TravelGuide = { ...insertTravelGuide, id };
    this.travelGuides.set(id, travelGuide);
    return travelGuide;
  }

  // Inquiry methods
  async getInquiries(): Promise<Inquiry[]> {
    return Array.from(this.inquiries.values());
  }

  async createInquiry(insertInquiry: InsertInquiry): Promise<Inquiry> {
    const id = this.inquiryId++;
    const inquiry: Inquiry = { 
      ...insertInquiry, 
      id, 
      createdAt: new Date() 
    };
    this.inquiries.set(id, inquiry);
    return inquiry;
  }

  // Helper to initialize with sample data
  private initializeData() {
    // Add some sample locations
    this.createLocation({
      name: "Redwood Village",
      type: "rural",
      description: "A small rural community surrounded by forests",
      latitude: "34.0522",
      longitude: "-118.2437"
    });

    this.createLocation({
      name: "Eastport City",
      type: "urban",
      description: "A major urban center with extensive public transportation",
      latitude: "40.7128",
      longitude: "-74.0060"
    });

    this.createLocation({
      name: "Hillcrest",
      type: "rural",
      description: "A rural farming community with limited transportation options",
      latitude: "37.7749",
      longitude: "-122.4194"
    });

    this.createLocation({
      name: "Central Station",
      type: "urban",
      description: "The main transportation hub of the metropolitan area",
      latitude: "41.8781",
      longitude: "-87.6298"
    });

    // Add transport options
    this.createTransportOption({
      name: "Public Transit",
      type: "bus",
      description: "Information about local and regional public transit options connecting rural communities to urban centers.",
      iconName: "bus",
      features: ["Rural bus service schedules", "Regional train connections", "Intermodal transfer information"]
    });

    this.createTransportOption({
      name: "Shared Rides",
      type: "carpool",
      description: "Community-based transportation options for rural residents through organized carpooling and ride-sharing.",
      iconName: "users",
      features: ["Local community ride pools", "Rural-to-urban regular vanpools", "On-demand ride requests"]
    });

    this.createTransportOption({
      name: "On-Demand Services",
      type: "shuttle",
      description: "Specialized transportation services that operate in rural areas with booking options.",
      iconName: "clipboard",
      features: ["Rural area shuttle services", "Local taxi and car services", "Advanced booking information"]
    });

    // Add routes
    this.createRoute({
      fromLocationId: 1, // Redwood Village
      toLocationId: 2, // Eastport City
      transportOptionId: 1, // Public Transit
      duration: 120, // 2 hours
      price: 1500, // $15.00
      schedule: "Daily at 8:00 AM and 4:00 PM",
      isPopular: true
    });

    this.createRoute({
      fromLocationId: 3, // Hillcrest
      toLocationId: 4, // Central Station
      transportOptionId: 3, // On-Demand Services
      duration: 90, // 1.5 hours
      price: 2500, // $25.00
      schedule: "On-demand booking required 24 hours in advance",
      isPopular: true
    });

    // Add travel guides
    this.createTravelGuide({
      title: "Rural Transport Tips",
      description: "Essential information for navigating transportation in rural communities.",
      content: "Long-form content about rural transport options and tips...",
      type: "Tips",
      highlights: [
        "Check schedules in advance",
        "Call to confirm",
        "Carry cash"
      ]
    });

    this.createTravelGuide({
      title: "Transit Connections",
      description: "How to navigate transfers between rural and urban transportation systems.",
      content: "Detailed guide about making connections between different transit systems...",
      type: "Connections",
      highlights: [
        "Major transfer points",
        "Transfer timing",
        "Fare coordination"
      ]
    });

    this.createTravelGuide({
      title: "Seasonal Considerations",
      description: "How weather and seasons affect rural transportation options.",
      content: "Information about how transportation changes with seasons in rural areas...",
      type: "Seasonal",
      highlights: [
        "Winter travel adjustments",
        "Harvest season impacts",
        "Tourist season"
      ]
    });
  }
}

export const storage = new MemStorage();
