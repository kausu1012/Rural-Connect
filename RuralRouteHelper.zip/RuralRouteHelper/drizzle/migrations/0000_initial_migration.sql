-- Create enum types
CREATE TYPE "location_type" AS ENUM ('rural', 'urban', 'suburban', 'remote');
CREATE TYPE "transport_type" AS ENUM ('bus', 'train', 'car', 'taxi', 'auto', 'bike', 'walking');
CREATE TYPE "guide_type" AS ENUM ('general', 'seasonal', 'travel_tips', 'emergency', 'local_culture');

-- Create users table
CREATE TABLE IF NOT EXISTS "users" (
  "id" SERIAL PRIMARY KEY,
  "username" TEXT NOT NULL UNIQUE,
  "password" TEXT NOT NULL,
  "email" TEXT,
  "full_name" TEXT,
  "phone" TEXT,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Create locations table
CREATE TABLE IF NOT EXISTS "locations" (
  "id" SERIAL PRIMARY KEY,
  "name" TEXT NOT NULL,
  "type" location_type NOT NULL,
  "description" TEXT,
  "latitude" REAL,
  "longitude" REAL,
  "region" TEXT,
  "district" TEXT,
  "state" TEXT,
  "population" INTEGER,
  "amenities" TEXT[],
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create transport options table
CREATE TABLE IF NOT EXISTS "transport_options" (
  "id" SERIAL PRIMARY KEY,
  "name" TEXT NOT NULL,
  "type" transport_type NOT NULL,
  "description" TEXT,
  "icon_name" TEXT,
  "features" TEXT[],
  "capacity" INTEGER,
  "accessibility" BOOLEAN DEFAULT FALSE,
  "cost_per_km" NUMERIC(10, 2),
  "operator" TEXT,
  "contact_info" TEXT,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create routes table with foreign key references
CREATE TABLE IF NOT EXISTS "routes" (
  "id" SERIAL PRIMARY KEY,
  "from_location_id" INTEGER NOT NULL REFERENCES "locations"("id"),
  "to_location_id" INTEGER NOT NULL REFERENCES "locations"("id"),
  "transport_option_id" INTEGER NOT NULL REFERENCES "transport_options"("id"),
  "duration" INTEGER NOT NULL,
  "distance" NUMERIC(10, 2),
  "price" NUMERIC(10, 2),
  "schedule" TEXT,
  "frequency" TEXT,
  "is_popular" BOOLEAN DEFAULT FALSE,
  "is_active" BOOLEAN DEFAULT TRUE,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create travel guides table
CREATE TABLE IF NOT EXISTS "travel_guides" (
  "id" SERIAL PRIMARY KEY,
  "title" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "content" TEXT NOT NULL,
  "type" guide_type DEFAULT 'general' NOT NULL,
  "highlights" TEXT[],
  "author" TEXT,
  "location_id" INTEGER REFERENCES "locations"("id"),
  "image_url" TEXT,
  "published_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create inquiries table for contact form
CREATE TABLE IF NOT EXISTS "inquiries" (
  "id" SERIAL PRIMARY KEY,
  "name" TEXT NOT NULL,
  "email" TEXT NOT NULL,
  "subject" TEXT NOT NULL,
  "message" TEXT NOT NULL,
  "phone" TEXT,
  "requires_sms" BOOLEAN DEFAULT FALSE,
  "status" TEXT DEFAULT 'new',
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create reviews table for routes/locations
CREATE TABLE IF NOT EXISTS "reviews" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER REFERENCES "users"("id"),
  "route_id" INTEGER REFERENCES "routes"("id"),
  "location_id" INTEGER REFERENCES "locations"("id"),
  "rating" INTEGER NOT NULL,
  "title" TEXT,
  "comment" TEXT,
  "date_of_travel" TIMESTAMP,
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS "idx_locations_type" ON "locations" ("type");
CREATE INDEX IF NOT EXISTS "idx_transport_options_type" ON "transport_options" ("type");
CREATE INDEX IF NOT EXISTS "idx_routes_from_to" ON "routes" ("from_location_id", "to_location_id");
CREATE INDEX IF NOT EXISTS "idx_routes_popular" ON "routes" ("is_popular") WHERE "is_popular" = TRUE;
CREATE INDEX IF NOT EXISTS "idx_travel_guides_type" ON "travel_guides" ("type");
CREATE INDEX IF NOT EXISTS "idx_inquiries_status" ON "inquiries" ("status");