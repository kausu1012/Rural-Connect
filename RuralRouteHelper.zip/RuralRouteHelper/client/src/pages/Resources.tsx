import { useEffect } from "react";
import Layout from "@/components/Layout";
import { useQuery } from "@tanstack/react-query";
import { getTravelGuides, getTransportOptions } from "@/lib/api";
import { Download, ExternalLink, Map, FileText, Info, Phone } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Resources() {
  // Set meta tags for SEO
  useEffect(() => {
    document.title = "Travel Resources - RuralConnect";
  }, []);

  const { data: travelGuides, isLoading: guidesLoading } = useQuery({
    queryKey: ['/api/travel-guides'],
    queryFn: getTravelGuides
  });

  const { data: transportOptions, isLoading: optionsLoading } = useQuery({
    queryKey: ['/api/transport-options'],
    queryFn: getTransportOptions
  });

  const downloadResource = (resourceName: string) => {
    // In a real app, this would download the resource
    alert(`Downloading ${resourceName}...`);
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-3xl md:text-4xl font-heading font-bold mb-2">Travel Resources</h1>
        <p className="text-neutral-dark mb-8">Essential information and tools for rural travel planning</p>

        <Tabs defaultValue="guides" className="mb-10">
          <TabsList className="mb-6">
            <TabsTrigger value="guides">Travel Guides</TabsTrigger>
            <TabsTrigger value="maps">Maps & Routes</TabsTrigger>
            <TabsTrigger value="providers">Local Providers</TabsTrigger>
            <TabsTrigger value="offline">Offline Resources</TabsTrigger>
          </TabsList>

          <TabsContent value="guides">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {guidesLoading ? (
                Array(3).fill(0).map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader>
                      <div className="h-6 bg-gray-200 rounded w-3/4 mb-2"></div>
                      <div className="h-4 bg-gray-200 rounded w-full"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="h-4 bg-gray-200 rounded"></div>
                        <div className="h-4 bg-gray-200 rounded"></div>
                        <div className="h-4 bg-gray-200 rounded"></div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <div className="h-8 bg-gray-200 rounded w-full"></div>
                    </CardFooter>
                  </Card>
                ))
              ) : (
                travelGuides?.map((guide: any) => (
                  <Card key={guide.id}>
                    <CardHeader>
                      <CardTitle>{guide.title}</CardTitle>
                      <CardDescription>{guide.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-1">
                        {guide.highlights.map((highlight: string, idx: number) => (
                          <li key={idx} className="flex items-center text-sm">
                            <Info className="h-4 w-4 mr-2 text-primary" />
                            <span>{highlight}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Button 
                        onClick={() => downloadResource(guide.title)}
                        className="w-full"
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Download Guide
                      </Button>
                    </CardFooter>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="maps">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-heading font-semibold mb-4">
                Rural-Urban Transportation Maps
              </h2>
              <p className="text-neutral-dark mb-6">
                Download these maps for offline use when traveling in areas with limited connectivity.
                All maps include transportation options, schedules, and key transfer points.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Regional Bus Routes</CardTitle>
                    <CardDescription>Complete map of rural bus routes</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-32 bg-neutral-lightest rounded-md flex items-center justify-center">
                      <Map className="h-10 w-10 text-primary opacity-40" />
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">
                      <Download className="h-4 w-4 mr-2" />
                      Download (4.2MB)
                    </Button>
                  </CardFooter>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Train Connections</CardTitle>
                    <CardDescription>Rural to urban train routes</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-32 bg-neutral-lightest rounded-md flex items-center justify-center">
                      <Map className="h-10 w-10 text-primary opacity-40" />
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">
                      <Download className="h-4 w-4 mr-2" />
                      Download (3.8MB)
                    </Button>
                  </CardFooter>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Transit Hubs</CardTitle>
                    <CardDescription>Major transfer points and schedules</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-32 bg-neutral-lightest rounded-md flex items-center justify-center">
                      <Map className="h-10 w-10 text-primary opacity-40" />
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">
                      <Download className="h-4 w-4 mr-2" />
                      Download (2.1MB)
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="providers">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {optionsLoading ? (
                Array(2).fill(0).map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader>
                      <div className="h-6 bg-gray-200 rounded w-3/4 mb-2"></div>
                      <div className="h-4 bg-gray-200 rounded w-full"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="h-4 bg-gray-200 rounded"></div>
                        <div className="h-4 bg-gray-200 rounded"></div>
                        <div className="h-4 bg-gray-200 rounded"></div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <div className="h-8 bg-gray-200 rounded w-full"></div>
                    </CardFooter>
                  </Card>
                ))
              ) : (
                transportOptions?.map((option: any) => (
                  <Card key={option.id}>
                    <CardHeader>
                      <CardTitle>{option.name} Providers</CardTitle>
                      <CardDescription>{option.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="p-3 bg-neutral-lightest rounded-md border border-neutral-light">
                          <div className="font-medium">Regional Transit Authority</div>
                          <div className="flex items-center text-sm mt-1">
                            <Phone className="h-4 w-4 mr-2 text-primary" />
                            <span>1-800-555-TRANSIT</span>
                          </div>
                          <Button variant="link" size="sm" className="px-0 h-auto mt-1">
                            <ExternalLink className="h-3 w-3 mr-1" />
                            Visit website
                          </Button>
                        </div>

                        <div className="p-3 bg-neutral-lightest rounded-md border border-neutral-light">
                          <div className="font-medium">Community Ride Service</div>
                          <div className="flex items-center text-sm mt-1">
                            <Phone className="h-4 w-4 mr-2 text-primary" />
                            <span>1-877-RIDE-HELP</span>
                          </div>
                          <Button variant="link" size="sm" className="px-0 h-auto mt-1">
                            <ExternalLink className="h-3 w-3 mr-1" />
                            Visit website
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button variant="outline" className="w-full">
                        <FileText className="h-4 w-4 mr-2" />
                        Download Complete Provider List
                      </Button>
                    </CardFooter>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="offline">
            <div className="bg-white p-6 rounded-lg shadow-md mb-6">
              <h2 className="text-xl font-heading font-semibold mb-4">
                Offline Access Instructions
              </h2>
              <p className="text-neutral-dark mb-4">
                Follow these steps to make RuralConnect resources available when you don't have internet connectivity:
              </p>

              <ol className="list-decimal list-inside space-y-2 ml-4 mb-6">
                <li className="text-neutral-dark">
                  Click the "Enable Offline Mode" button below to allow the app to store resources locally
                </li>
                <li className="text-neutral-dark">
                  Download the specific guides, maps or schedules you need for your journey
                </li>
                <li className="text-neutral-dark">
                  Access your saved items from the "Saved Resources" section even when offline
                </li>
                <li className="text-neutral-dark">
                  Updates to saved resources will be applied automatically when you reconnect
                </li>
              </ol>

              <Button className="bg-primary">
                <Download className="h-4 w-4 mr-2" />
                Enable Offline Mode
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Printable Schedules</CardTitle>
                  <CardDescription>Low-bandwidth PDF schedules</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-neutral-dark">
                    Compact printer-friendly schedules for all rural transportation services.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">
                    <Download className="h-4 w-4 mr-2" />
                    Download PDF Pack
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Emergency Contacts</CardTitle>
                  <CardDescription>Rural area service contacts</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-neutral-dark">
                    Complete list of emergency and transportation assistance contacts for rural areas.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">
                    <Download className="h-4 w-4 mr-2" />
                    Download Contact List
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Text-Only Guide</CardTitle>
                  <CardDescription>Ultra low bandwidth version</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-neutral-dark">
                    Text-only version of all guides and resources, optimized for the slowest connections.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">
                    <Download className="h-4 w-4 mr-2" />
                    Download Text Guide
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
