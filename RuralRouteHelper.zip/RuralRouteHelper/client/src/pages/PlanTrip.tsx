import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import Layout from "@/components/Layout";
import { useQuery } from "@tanstack/react-query";
import { searchRoutes } from "@/lib/api";
import { RouteInfo, SearchParams } from "@/lib/types";
import RouteCard from "@/components/RouteCard";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { CalendarIcon, Search } from "lucide-react";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";

const searchSchema = z.object({
  departure: z.string().min(1, "Departure location is required"),
  arrival: z.string().min(1, "Destination is required"),
  date: z.date({
    required_error: "Please select a date",
  }),
  passengers: z.string().min(1, "Please select number of passengers"),
});

export default function PlanTrip() {
  const [location] = useLocation();
  const [searchParams, setSearchParams] = useState<SearchParams | null>(null);
  
  // Extract query parameters
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const from = params.get('from');
    const to = params.get('to');
    const date = params.get('date');
    const passengers = params.get('passengers');
    
    if (from && to && date) {
      setSearchParams({
        departure: from,
        arrival: to,
        date: date,
        passengers: parseInt(passengers || '1')
      });
      
      form.setValue('departure', from);
      form.setValue('arrival', to);
      
      // Try to parse date
      try {
        const dateObj = new Date(date);
        if (!isNaN(dateObj.getTime())) {
          form.setValue('date', dateObj);
        }
      } catch (e) {
        console.error("Invalid date format in URL");
      }
      
      form.setValue('passengers', passengers || '1');
    }
  }, [location]);
  
  // Set up the search form
  const form = useForm<z.infer<typeof searchSchema>>({
    resolver: zodResolver(searchSchema),
    defaultValues: {
      departure: "",
      arrival: "",
      passengers: "1",
    },
  });
  
  // Handle form submission
  const onSubmit = (data: z.infer<typeof searchSchema>) => {
    const newParams: SearchParams = {
      departure: data.departure,
      arrival: data.arrival,
      date: format(data.date, "yyyy-MM-dd"),
      passengers: parseInt(data.passengers),
    };
    
    setSearchParams(newParams);
    
    // Update URL with search params
    const url = `/plan-trip?from=${encodeURIComponent(newParams.departure)}&to=${encodeURIComponent(newParams.arrival)}&date=${newParams.date}&passengers=${newParams.passengers}`;
    window.history.pushState({}, '', url);
  };
  
  // Fetch routes based on search parameters
  const { data: routes, isLoading, error } = useQuery({
    queryKey: ['/api/search-routes', searchParams?.departure, searchParams?.arrival, searchParams?.date],
    queryFn: () => searchParams ? searchRoutes(searchParams) : Promise.resolve([]),
    enabled: !!searchParams,
  });

  // Set meta tags for SEO
  useEffect(() => {
    document.title = "Plan Your Trip - RuralConnect";
  }, []);

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-heading font-bold mb-6">Plan Your Trip</h1>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-heading font-semibold mb-4">Search for Routes</h2>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="departure"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>From</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter departure location" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="arrival"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>To</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter destination" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) =>
                              date < new Date(new Date().setHours(0, 0, 0, 0))
                            }
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="passengers"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Passengers</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select passengers" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="1">1 passenger</SelectItem>
                          <SelectItem value="2">2 passengers</SelectItem>
                          <SelectItem value="3">3 passengers</SelectItem>
                          <SelectItem value="4">4+ passengers</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <Button type="submit" className="w-full md:w-auto bg-secondary hover:bg-secondary-light">
                <Search className="h-4 w-4 mr-2" />
                Search Routes
              </Button>
            </form>
          </Form>
        </div>
        
        {/* Results */}
        <div>
          <h2 className="text-2xl font-heading font-semibold mb-4">
            {searchParams ? `Routes from ${searchParams.departure} to ${searchParams.arrival}` : "Enter locations to see routes"}
          </h2>
          
          {isLoading && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[1, 2, 3, 4].map(n => (
                <div key={n} className="bg-white rounded-lg shadow-md p-4 animate-pulse h-48">
                  <div className="flex justify-between items-start mb-3">
                    <div className="w-1/2">
                      <div className="h-5 bg-gray-200 rounded mb-2"></div>
                      <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                    </div>
                    <div className="h-6 w-16 bg-gray-200 rounded"></div>
                  </div>
                  <div className="space-y-2 mb-4">
                    <div className="h-4 bg-gray-200 rounded"></div>
                    <div className="h-4 bg-gray-200 rounded"></div>
                    <div className="h-4 bg-gray-200 rounded"></div>
                  </div>
                  <div className="h-0.5 bg-gray-200 mb-3"></div>
                  <div className="flex justify-between">
                    <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          {error && (
            <div className="bg-red-50 border border-red-200 p-4 rounded-md text-red-600">
              <p>Error loading routes. Please try again later.</p>
            </div>
          )}
          
          {!isLoading && !error && routes && routes.length === 0 && searchParams && (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <p className="text-lg text-neutral-dark mb-4">No routes found for your search.</p>
              <p className="text-neutral-dark">Try different locations or dates.</p>
            </div>
          )}
          
          {!isLoading && !error && routes && routes.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {routes.map((route: RouteInfo) => (
                <RouteCard key={route.id} route={route} />
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
