import Layout from "@/components/Layout";
import HeroSection from "@/components/HeroSection";
import FeaturesSection from "@/components/FeaturesSection";
import HowItWorksSection from "@/components/HowItWorksSection";
import TransportationOptionsSection from "@/components/TransportationOptionsSection";
import MapSection from "@/components/MapSection";
import OfflineTravelGuideSection from "@/components/OfflineTravelGuideSection";
import ContactSection from "@/components/ContactSection";

export default function Home() {
  return (
    <Layout>
      <HeroSection />
      <FeaturesSection />
      <HowItWorksSection />
      <TransportationOptionsSection />
      <MapSection />
      <OfflineTravelGuideSection />
      <ContactSection />
    </Layout>
  );
}
