import { useEffect } from "react";
import Layout from "@/components/Layout";
import { useQuery } from "@tanstack/react-query";
import { getTravelGuides } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, Download } from "lucide-react";

export default function TravelGuide() {
  const { data: travelGuides, isLoading, error } = useQuery({
    queryKey: ['/api/travel-guides'],
    queryFn: getTravelGuides
  });

  // Set meta tags for SEO
  useEffect(() => {
    document.title = "Travel Guides - RuralConnect";
  }, []);

  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12">
          <h1 className="text-3xl md:text-4xl font-heading font-bold mb-8">Travel Guides</h1>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map(n => (
              <div key={n} className="bg-white rounded-lg shadow p-5 animate-pulse h-64">
                <div className="h-6 bg-gray-200 rounded w-1/2 mb-4"></div>
                <div className="h-4 bg-gray-200 rounded mb-6 w-3/4"></div>
                <div className="space-y-3 mb-4">
                  <div className="h-12 bg-gray-200 rounded"></div>
                  <div className="h-12 bg-gray-200 rounded"></div>
                  <div className="h-12 bg-gray-200 rounded"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12">
          <h1 className="text-3xl md:text-4xl font-heading font-bold mb-8">Travel Guides</h1>
          <div className="text-center text-red-500 p-8 bg-white rounded-lg shadow">
            <p>Failed to load travel guides. Please try again later.</p>
            <Button onClick={() => window.location.reload()} className="mt-4">
              Retry
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-12">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl md:text-4xl font-heading font-bold">Rural Travel Guides</h1>
          <Button className="bg-accent hover:bg-accent-light text-white font-medium inline-flex items-center">
            <Download className="h-5 w-5 mr-1" />
            Download All Guides
          </Button>
        </div>

        <p className="text-lg text-neutral-dark mb-8">
          Comprehensive information to help you navigate travel between rural and urban areas, 
          with tips for making your journey smoother and more reliable.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {travelGuides?.map((guide: any) => (
            <Card key={guide.id} className="bg-white shadow-md">
              <CardHeader>
                <CardTitle className="text-xl font-heading font-semibold">{guide.title}</CardTitle>
                <CardDescription>{guide.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {guide.highlights.map((highlight: string, idx: number) => (
                    <li key={idx} className="flex items-start">
                      <Check className="h-5 w-5 text-accent mr-2 flex-shrink-0" />
                      <div>
                        <span className="font-medium">{highlight}</span>
                        <p className="text-sm text-neutral-dark">
                          {idx === 0 && "Essential information for rural travelers to plan ahead."}
                          {idx === 1 && "Practical advice for navigating transportation options."}
                          {idx === 2 && "Important tips to ensure a smooth journey."}
                        </p>
                      </div>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" className="text-primary">Read Full Guide</Button>
                <Button variant="ghost" size="sm" className="text-neutral-dark">
                  <Download className="h-4 w-4 mr-1" />
                  Save Offline
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
}
