import { useEffect } from "react";
import Layout from "@/components/Layout";
import ContactSection from "@/components/ContactSection";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

export default function Contact() {
  // Set meta tags for SEO
  useEffect(() => {
    document.title = "Contact Us - RuralConnect";
  }, []);

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-heading font-bold mb-2">Contact Us</h1>
        <p className="text-neutral-dark mb-8">
          We're here to help with your rural travel needs and questions
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center">
                <Phone className="h-5 w-5 mr-2 text-primary" />
                Phone Support
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-neutral-dark mb-2">
                Call us directly for immediate assistance with travel planning.
              </p>
              <div className="font-medium">1-800-RURALCONNECT</div>
              <div className="text-sm text-neutral-dark mt-1 flex items-center">
                <Clock className="h-4 w-4 mr-1" />
                Monday-Friday: 8am-8pm
              </div>
              <div className="text-sm text-neutral-dark mt-1 flex items-center">
                <Clock className="h-4 w-4 mr-1" />
                Saturday: 9am-5pm
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center">
                <Mail className="h-5 w-5 mr-2 text-primary" />
                Email & SMS
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-neutral-dark mb-2">
                For non-urgent inquiries or in areas with limited connectivity.
              </p>
              <div className="font-medium">help@ruralconnect.org</div>
              <div className="text-sm mt-2">SMS Support:</div>
              <div className="font-medium">Text "HELP" to 87611</div>
              <p className="text-xs text-neutral-dark mt-1">
                Standard message rates apply
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center">
                <MapPin className="h-5 w-5 mr-2 text-primary" />
                Regional Offices
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-neutral-dark mb-2">
                Visit us for in-person assistance with rural transportation options.
              </p>
              <div className="space-y-2">
                <div>
                  <div className="font-medium">Eastern Region Office</div>
                  <div className="text-sm text-neutral-dark">123 Main Street, Eastport</div>
                </div>
                <div>
                  <div className="font-medium">Western Region Office</div>
                  <div className="text-sm text-neutral-dark">456 Oak Road, Westville</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <ContactSection />
      </div>
    </Layout>
  );
}
