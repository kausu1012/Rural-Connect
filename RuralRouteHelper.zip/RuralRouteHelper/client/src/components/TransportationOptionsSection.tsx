import { Check, Bus, Users, ClipboardCheck } from "lucide-react";
import { Link } from "wouter";
import { TransportOption } from "@/lib/types";
import { useQuery } from "@tanstack/react-query";
import { getTransportOptions } from "@/lib/api";

export default function TransportationOptionsSection() {
  const { data: transportOptions, isLoading, error } = useQuery({
    queryKey: ['/api/transport-options'],
    queryFn: getTransportOptions
  });

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "bus":
        return <Bus className="h-5 w-5" />;
      case "users":
        return <Users className="h-5 w-5" />;
      case "clipboard":
        return <ClipboardCheck className="h-5 w-5" />;
      default:
        return <Bus className="h-5 w-5" />;
    }
  };

  const renderTransportOption = (option: any) => (
    <div key={option.id} className="bg-neutral-lightest rounded-lg shadow overflow-hidden">
      <div className="p-5">
        <h3 className="text-xl font-heading font-semibold mb-2">{option.name}</h3>
        <div className="flex items-center mb-3">
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white mr-2">
            {getIcon(option.iconName)}
          </div>
          <span className="text-neutral-dark text-sm">{option.type}</span>
        </div>
        <p className="text-neutral-dark text-sm mb-4">{option.description}</p>
        <ul className="text-sm text-neutral-dark space-y-2 mb-4">
          {option.features.map((feature: string, idx: number) => (
            <li key={idx} className="flex items-start">
              <Check className="h-5 w-5 text-accent mr-1 flex-shrink-0" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
        <Link href={`/travel-guide/${option.id}`}>
          <div className="text-primary font-medium text-sm inline-flex items-center cursor-pointer">
            Learn more
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
            </svg>
          </div>
        </Link>
      </div>
    </div>
  );

  if (isLoading) {
    return (
      <section className="py-10 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-heading font-bold text-center mb-8">
            Available Transportation Options
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map(n => (
              <div key={n} className="bg-neutral-lightest rounded-lg shadow p-5 animate-pulse h-64">
                <div className="h-6 bg-gray-200 rounded w-1/2 mb-4"></div>
                <div className="flex items-center mb-3">
                  <div className="w-8 h-8 bg-gray-200 rounded-full mr-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                </div>
                <div className="h-4 bg-gray-200 rounded mb-6"></div>
                <div className="h-4 bg-gray-200 rounded mb-2 w-3/4"></div>
                <div className="h-4 bg-gray-200 rounded mb-2 w-3/4"></div>
                <div className="h-4 bg-gray-200 rounded mb-4 w-3/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="py-10 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-heading font-bold text-center mb-8">
            Available Transportation Options
          </h2>
          <div className="text-center text-red-500">
            Failed to load transportation options. Please try again later.
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-10 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-heading font-bold text-center mb-8">
          Available Transportation Options
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {transportOptions?.map(renderTransportOption)}
        </div>
      </div>
    </section>
  );
}
