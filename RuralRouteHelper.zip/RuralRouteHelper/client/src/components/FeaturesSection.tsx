import { MapPin, Zap, Users } from "lucide-react";

import { Feature } from "@/lib/types";

export default function FeaturesSection() {
  const features: Feature[] = [
    {
      icon: "mapPin",
      title: "Rural Area Expertise",
      description: "Specialized knowledge of transportation options in remote and rural areas that other services don't cover."
    },
    {
      icon: "zap",
      title: "Low Bandwidth Design",
      description: "Optimized for areas with limited connectivity, with offline capabilities for essential information."
    },
    {
      icon: "users",
      title: "Community Insights",
      description: "Local knowledge and community-verified transportation options for reliable travel planning."
    }
  ];

  const renderIcon = (iconName: string) => {
    switch (iconName) {
      case "mapPin":
        return <MapPin className="h-6 w-6" />;
      case "zap":
        return <Zap className="h-6 w-6" />;
      case "users":
        return <Users className="h-6 w-6" />;
      default:
        return <MapPin className="h-6 w-6" />;
    }
  };

  return (
    <section className="py-10 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-heading font-bold text-center mb-8">
          Why RuralConnect?
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="feature-card bg-neutral-lightest p-6 rounded-lg shadow-sm border border-neutral-light"
            >
              <div className="w-12 h-12 bg-primary-light rounded-full flex items-center justify-center mb-4 text-white">
                {renderIcon(feature.icon)}
              </div>
              <h3 className="text-lg font-heading font-semibold mb-2">{feature.title}</h3>
              <p className="text-neutral-dark">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
