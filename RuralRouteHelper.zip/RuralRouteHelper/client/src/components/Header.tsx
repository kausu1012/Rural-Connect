import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [location] = useLocation();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const navLinks = [
    { name: "Home", path: "/" },
    { name: "Plan Trip", path: "/plan-trip" },
    { name: "Travel Guide", path: "/travel-guide" },
    { name: "Resources", path: "/resources" },
    { name: "Contact", path: "/contact" },
  ];

  return (
    <header className="bg-primary shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/">
            <div className="text-neutral-lightest text-xl font-heading font-bold cursor-pointer">
              RuralConnect
            </div>
          </Link>
        </div>

        <Button
          variant="ghost"
          size="icon"
          onClick={toggleMenu}
          className="lg:hidden text-neutral-lightest"
          aria-label="Toggle menu"
        >
          <Menu className="h-6 w-6" />
        </Button>

        <nav className="hidden lg:flex space-x-6">
          {navLinks.map((link) => (
            <Link key={link.path} href={link.path}>
              <div
                className={`text-neutral-lightest hover:text-white text-sm font-medium cursor-pointer ${
                  location === link.path ? "font-semibold" : ""
                }`}
              >
                {link.name}
              </div>
            </Link>
          ))}
        </nav>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <nav className="bg-primary-light lg:hidden px-4 py-2">
          <div className="flex flex-col space-y-3">
            {navLinks.map((link) => (
              <Link key={link.path} href={link.path}>
                <div
                  className={`text-neutral-lightest hover:text-white text-sm font-medium py-2 cursor-pointer ${
                    location === link.path ? "font-semibold" : ""
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  {link.name}
                </div>
              </Link>
            ))}
          </div>
        </nav>
      )}
    </header>
  );
}
