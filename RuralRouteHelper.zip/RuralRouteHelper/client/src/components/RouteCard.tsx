import { RouteInfo } from "@/lib/types";
import { Clock, DollarSign, Calendar } from "lucide-react";
import { formatDuration, formatPrice } from "@/lib/utils";

interface RouteCardProps {
  route: RouteInfo;
}

export default function RouteCard({ route }: RouteCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-4 border border-neutral-light">
      <div className="flex justify-between items-start mb-3">
        <div>
          <h3 className="font-heading font-semibold text-lg">
            {route.fromLocation.name} to {route.toLocation.name}
          </h3>
          <p className="text-sm text-neutral-dark">{route.transportOption.name}</p>
        </div>
        <div className="bg-primary text-white text-xs font-medium py-1 px-2 rounded">
          {route.transportOption.type}
        </div>
      </div>
      
      <div className="space-y-2 mb-4">
        <div className="flex items-center text-sm">
          <Clock className="h-4 w-4 mr-2 text-neutral-dark" />
          <span>Duration: {formatDuration(route.duration)}</span>
        </div>
        
        <div className="flex items-center text-sm">
          <DollarSign className="h-4 w-4 mr-2 text-neutral-dark" />
          <span>Price: {formatPrice(route.price)}</span>
        </div>
        
        <div className="flex items-center text-sm">
          <Calendar className="h-4 w-4 mr-2 text-neutral-dark" />
          <span>Schedule: {route.schedule}</span>
        </div>
      </div>
      
      <div className="flex justify-between items-center pt-3 border-t border-neutral-light">
        <span className="text-xs text-neutral-dark">Date: {route.date}</span>
        <button className="text-primary text-sm font-medium hover:underline">
          View Details
        </button>
      </div>
    </div>
  );
}
