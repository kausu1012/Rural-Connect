import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";

import { SearchParams } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";

const searchSchema = z.object({
  departure: z.string().min(1, "Departure location is required"),
  arrival: z.string().min(1, "Destination is required"),
  date: z.date({
    required_error: "Please select a date",
  }),
  passengers: z.string().min(1, "Please select number of passengers"),
});

export default function HeroSection() {
  const [, navigate] = useLocation();

  const form = useForm<z.infer<typeof searchSchema>>({
    resolver: zodResolver(searchSchema),
    defaultValues: {
      departure: "",
      arrival: "",
      passengers: "1",
    },
  });

  const onSubmit = (data: z.infer<typeof searchSchema>) => {
    const searchParams: SearchParams = {
      departure: data.departure,
      arrival: data.arrival,
      date: format(data.date, "yyyy-MM-dd"),
      passengers: parseInt(data.passengers),
    };

    // Navigate to search results with query params
    navigate(`/plan-trip?from=${searchParams.departure}&to=${searchParams.arrival}&date=${searchParams.date}&passengers=${searchParams.passengers}`);
  };

  return (
    <section className="relative bg-neutral-darkest">
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-black opacity-50"></div>
      
      {/* Background image would be implemented via CSS in production */}
      <div className="relative container mx-auto px-4 py-16 md:py-24 flex flex-col items-center justify-center text-center text-white">
        <h1 className="text-3xl md:text-4xl lg:text-5xl font-heading font-bold mb-4">
          Connect Rural & Urban Travel
        </h1>
        <p className="text-lg md:text-xl max-w-2xl mb-8">
          Find reliable transportation options and travel information for rural areas and connections to urban centers.
        </p>
        
        <div className="w-full max-w-md">
          <div className="bg-white p-4 rounded-lg shadow-lg">
            <h2 className="text-primary font-heading font-semibold text-lg mb-3">
              Where do you want to go?
            </h2>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
                <div className="flex flex-col md:flex-row md:space-x-2 space-y-3 md:space-y-0">
                  <FormField
                    control={form.control}
                    name="departure"
                    render={({ field }) => (
                      <FormItem className="flex-1">
                        <FormLabel className="block text-neutral-dark text-sm font-medium mb-1">From</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Departure location" 
                            {...field} 
                            className="w-full px-3 py-2 border border-neutral-light rounded-md focus:outline-none focus:ring-1 focus:ring-primary text-neutral-darkest"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="arrival"
                    render={({ field }) => (
                      <FormItem className="flex-1">
                        <FormLabel className="block text-neutral-dark text-sm font-medium mb-1">To</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Destination" 
                            {...field} 
                            className="w-full px-3 py-2 border border-neutral-light rounded-md focus:outline-none focus:ring-1 focus:ring-primary text-neutral-darkest"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="flex flex-col md:flex-row md:space-x-2 space-y-3 md:space-y-0">
                  <FormField
                    control={form.control}
                    name="date"
                    render={({ field }) => (
                      <FormItem className="flex-1">
                        <FormLabel className="block text-neutral-dark text-sm font-medium mb-1">Date</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={cn(
                                  "w-full px-3 py-2 border border-neutral-light text-left font-normal",
                                  !field.value && "text-muted-foreground"
                                )}
                              >
                                {field.value ? (
                                  format(field.value, "PPP")
                                ) : (
                                  <span>Pick a date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              disabled={(date) =>
                                date < new Date(new Date().setHours(0, 0, 0, 0))
                              }
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="passengers"
                    render={({ field }) => (
                      <FormItem className="flex-1">
                        <FormLabel className="block text-neutral-dark text-sm font-medium mb-1">Passengers</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="w-full px-3 py-2 border border-neutral-light">
                              <SelectValue placeholder="Select passengers" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="1">1 passenger</SelectItem>
                            <SelectItem value="2">2 passengers</SelectItem>
                            <SelectItem value="3">3 passengers</SelectItem>
                            <SelectItem value="4">4+ passengers</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <Button 
                  type="submit"
                  className="w-full bg-secondary hover:bg-secondary-light text-white font-medium py-2 px-4 rounded-md transition duration-200 ease-in-out"
                >
                  Find Routes
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </section>
  );
}
