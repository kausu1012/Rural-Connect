import { useState, useEffect, useCallback, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronRight, Plus, Minus, Car, Bus, Train, MapPin } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { getPopularRoutes } from "@/lib/api";
import { RouteInfo } from "@/lib/types";
import { useGoogleMaps } from "@/hooks/use-google-maps";

// Define transportation vehicle options
const vehicleOptions = [
  { id: 'car', name: 'Car', icon: Car, description: 'Personal vehicle or taxi', capacity: '1-4 people', speed: 'Fast' },
  { id: 'bus', name: 'Bus', icon: Bus, description: 'Public transportation', capacity: '20+ people', speed: 'Medium' },
  { id: 'train', name: 'Train', icon: Train, description: 'Rail service', capacity: '50+ people', speed: 'Fast' },
];

export default function MapSection() {
  const [fromLocation, setFromLocation] = useState("");
  const [toLocation, setToLocation] = useState("");
  const [mapLoaded, setMapLoaded] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState('car');
  const [vehicleDetails, setVehicleDetails] = useState(vehicleOptions[0]);
  const [showVehicleDetails, setShowVehicleDetails] = useState(false);
  const mapRef = useRef(null);
  const mapContainerRef = useRef(null);

  // Initialize Google Maps with our custom hook
  const { status, isLoaded, loadGoogleMapsScript } = useGoogleMaps({
    autoload: false, // We'll load it manually when the user clicks "Load Map"
    libraries: ['places', 'geometry']
  });

  const { data: popularRoutes } = useQuery({
    queryKey: ['/api/routes/popular'],
    queryFn: getPopularRoutes
  });

  useEffect(() => {
    // Update vehicle details when selection changes
    const selectedVehicleData = vehicleOptions.find(v => v.id === selectedVehicle);
    if (selectedVehicleData) {
      setVehicleDetails(selectedVehicleData);
    }
  }, [selectedVehicle]);

  // Initialize Google Maps when loaded and container is ready
  useEffect(() => {
    if (isLoaded && mapLoaded && mapContainerRef.current && !mapRef.current) {
      try {
        // Initialize the map
        mapRef.current = new window.google.maps.Map(mapContainerRef.current, {
          center: { lat: 40.7128, lng: -74.0060 }, // Default center (New York)
          zoom: 8,
          mapTypeId: 'roadmap',
          fullscreenControl: false,
          mapTypeControl: false,
          streetViewControl: false
        });
        
        // If we have locations, try to calculate route
        if (fromLocation && toLocation) {
          calculateRoute();
        }
      } catch (error) {
        console.error("Error initializing Google Maps:", error);
      }
    }
  }, [isLoaded, mapLoaded]);

  // Function to calculate route between locations
  const calculateRoute = useCallback(() => {
    if (!isLoaded || !mapRef.current || !fromLocation || !toLocation) return;

    try {
      const directionsService = new window.google.maps.DirectionsService();
      const directionsRenderer = new window.google.maps.DirectionsRenderer({
        map: mapRef.current,
        suppressMarkers: false
      });

      directionsService.route(
        {
          origin: fromLocation,
          destination: toLocation,
          travelMode: window.google.maps.TravelMode[
            selectedVehicle === 'car' ? 'DRIVING' : 
            selectedVehicle === 'bus' ? 'TRANSIT' : 'TRANSIT'
          ],
        },
        (result, status) => {
          if (status === 'OK') {
            directionsRenderer.setDirections(result);
          } else {
            console.error(`Route calculation failed: ${status}`);
          }
        }
      );
    } catch (error) {
      console.error("Error calculating route:", error);
    }
  }, [fromLocation, toLocation, isLoaded, selectedVehicle]);

  const handleShowRoutes = () => {
    setMapLoaded(true);
    
    // If Google Maps is loaded, calculate route
    if (isLoaded && mapRef.current) {
      calculateRoute();
    } else if (status !== 'loading') {
      // Try to load Google Maps if it's not already loading
      loadGoogleMapsScript();
    }
    
    console.log("Showing routes from", fromLocation, "to", toLocation, "using", selectedVehicle);
  };

  const handleEnableMap = () => {
    setMapLoaded(true);
    // Try to load Google Maps
    if (status !== 'loading' && status !== 'ready') {
      loadGoogleMapsScript();
    }
  };
  
  const handleVehicleSelect = (vehicleId: string) => {
    setSelectedVehicle(vehicleId);
    setShowVehicleDetails(true);
    
    // Recalculate route with new vehicle if map is already loaded
    if (isLoaded && mapRef.current && fromLocation && toLocation) {
      calculateRoute();
    }
  };

  return (
    <section className="py-10 bg-neutral-lightest">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-heading font-bold text-center mb-8">
          Find Rural Routes
        </h2>
        
        <div className="bg-white p-4 rounded-lg shadow-md">
          <div className="flex flex-col md:flex-row md:space-x-4">
            <div className="md:w-1/3 mb-4 md:mb-0">
              <div className="mb-6">
                <h3 className="text-lg font-heading font-semibold mb-3">Search for Routes</h3>
                <div className="space-y-3">
                  <div>
                    <label htmlFor="map-from" className="block text-neutral-dark text-sm font-medium mb-1">From</label>
                    <Input 
                      type="text" 
                      id="map-from" 
                      placeholder="Starting point" 
                      value={fromLocation}
                      onChange={(e) => setFromLocation(e.target.value)}
                      className="w-full px-3 py-2 border border-neutral-light rounded-md focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label htmlFor="map-to" className="block text-neutral-dark text-sm font-medium mb-1">To</label>
                    <Input 
                      type="text" 
                      id="map-to" 
                      placeholder="Destination" 
                      value={toLocation}
                      onChange={(e) => setToLocation(e.target.value)}
                      className="w-full px-3 py-2 border border-neutral-light rounded-md focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>
                  
                  {/* Vehicle selection section */}
                  <div>
                    <label className="block text-neutral-dark text-sm font-medium mb-1">Transport Mode</label>
                    <div className="grid grid-cols-3 gap-2">
                      {vehicleOptions.map((vehicle) => {
                        const VehicleIcon = vehicle.icon;
                        return (
                          <Button
                            key={vehicle.id}
                            type="button"
                            variant={selectedVehicle === vehicle.id ? "default" : "outline"}
                            className={`p-2 flex flex-col items-center justify-center h-auto 
                              ${selectedVehicle === vehicle.id ? 'bg-primary text-white' : 'bg-white'}
                            `}
                            onClick={() => handleVehicleSelect(vehicle.id)}
                          >
                            <VehicleIcon className="h-5 w-5 mb-1" />
                            <span className="text-xs">{vehicle.name}</span>
                          </Button>
                        );
                      })}
                    </div>
                  </div>
                  
                  {/* Vehicle details section that appears when a vehicle is selected */}
                  {showVehicleDetails && (
                    <div className="border border-neutral-light rounded p-3 text-sm bg-neutral-lightest">
                      <h4 className="font-medium mb-1 flex items-center">
                        {(() => {
                          const VehicleIcon = vehicleDetails.icon;
                          return <VehicleIcon className="h-4 w-4 mr-2" />;
                        })()}
                        {vehicleDetails.name} Details
                      </h4>
                      <p className="text-xs mb-1">{vehicleDetails.description}</p>
                      <div className="flex justify-between mt-2 text-xs">
                        <span className="font-medium">Capacity:</span>
                        <span>{vehicleDetails.capacity}</span>
                      </div>
                      <div className="flex justify-between mt-1 text-xs">
                        <span className="font-medium">Speed:</span>
                        <span>{vehicleDetails.speed}</span>
                      </div>
                    </div>
                  )}
                  
                  <Button 
                    onClick={handleShowRoutes}
                    className="w-full bg-primary hover:bg-primary-light text-white font-medium py-2 px-4 rounded-md transition duration-200 ease-in-out"
                  >
                    Show Routes
                  </Button>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-heading font-semibold mb-3">Saved Routes</h3>
                <div className="space-y-2">
                  {popularRoutes?.slice(0, 2).map((route: RouteInfo) => (
                    <div 
                      key={route.id}
                      className="border border-neutral-light rounded-md p-3 hover:bg-neutral-lightest cursor-pointer"
                      onClick={() => {
                        setFromLocation(route.fromLocation.name);
                        setToLocation(route.toLocation.name);
                        // Auto-select the transport type based on route
                        const transportType = route.transportOption.type;
                        if (transportType === 'bus') setSelectedVehicle('bus');
                        else if (transportType === 'train') setSelectedVehicle('train');
                        else setSelectedVehicle('car');
                      }}
                    >
                      <div className="flex justify-between items-center">
                        <div>
                          <div className="font-medium text-sm">
                            {route.fromLocation.name} to {route.toLocation.name}
                          </div>
                          <div className="text-xs text-neutral-dark">
                            {route.transportOption.name}
                          </div>
                        </div>
                        <ChevronRight className="h-5 w-5 text-neutral-dark" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="md:w-2/3 h-96 bg-neutral-lightest rounded-lg border border-neutral-light relative" id="map-container">
              {!mapLoaded ? (
                <div className="absolute inset-0 p-4 flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-neutral-dark mb-3">
                      <h3 className="font-medium mb-2">Map Visualization</h3>
                      <p className="text-sm">Interactive map showing rural-urban transport routes</p>
                    </div>
                    <Button 
                      id="enableMap" 
                      onClick={handleEnableMap}
                      className="bg-primary hover:bg-primary-light text-white font-medium py-2 px-4 rounded-md transition duration-200 ease-in-out"
                    >
                      Load Map
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="absolute inset-0">
                  <div className="h-full relative">
                    {/* Map header */}
                    <div className="absolute top-0 left-0 right-0 z-10 bg-white bg-opacity-90 border-b border-neutral-light p-2 flex justify-between items-center">
                      <div className="font-medium text-sm">
                        {fromLocation && toLocation ? `${fromLocation} to ${toLocation}` : 'Rural-Urban Routes'}
                      </div>
                      <div className="text-xs bg-primary-light text-white px-2 py-1 rounded">
                        {selectedVehicle === 'car' ? 'Car' : selectedVehicle === 'bus' ? 'Bus' : 'Train'}
                      </div>
                    </div>
                    
                    {/* Container for Google Maps (if API key available) */}
                    {status === 'ready' ? (
                      <div ref={mapContainerRef} className="w-full h-full"></div>
                    ) : (
                      /* Fallback map visualization when Google Maps is not available */
                      <div className="p-4 pt-10">
                        <div className="relative h-[calc(100%-10px)] bg-[#f0f7ff] border border-neutral-light rounded-lg overflow-hidden">
                          {/* Simple map elements */}
                          <div className="absolute top-0 left-0 w-full h-full">
                            {/* Grid lines */}
                            <div className="absolute inset-0 grid grid-cols-6 grid-rows-6">
                              {Array.from({ length: 6 }).map((_, i) => (
                                <div key={`grid-row-${i}`} className="border-b border-gray-200" />
                              ))}
                              {Array.from({ length: 6 }).map((_, i) => (
                                <div key={`grid-col-${i}`} className="border-r border-gray-200" />
                              ))}
                            </div>
                            
                            {/* Route path if both locations are specified */}
                            {fromLocation && toLocation && (
                              <>
                                {/* Origin point with icon */}
                                <div className="absolute top-1/4 left-1/4 transform -translate-x-1/2 -translate-y-1/2 z-10">
                                  <div className="bg-white rounded-full p-1.5 shadow-md">
                                    <MapPin className="h-5 w-5 text-primary" />
                                  </div>
                                  <div className="absolute top-full mt-1 left-1/2 transform -translate-x-1/2 whitespace-nowrap text-xs font-medium bg-white px-2 py-0.5 rounded shadow-sm">
                                    {fromLocation}
                                  </div>
                                </div>
                                
                                {/* Destination point with icon */}
                                <div className="absolute bottom-1/4 right-1/4 transform translate-x-1/2 translate-y-1/2 z-10">
                                  <div className="bg-white rounded-full p-1.5 shadow-md">
                                    <MapPin className="h-5 w-5 text-secondary" />
                                  </div>
                                  <div className="absolute top-full mt-1 left-1/2 transform -translate-x-1/2 whitespace-nowrap text-xs font-medium bg-white px-2 py-0.5 rounded shadow-sm">
                                    {toLocation}
                                  </div>
                                </div>
                                
                                {/* Route line based on transport mode */}
                                <div className={`
                                  absolute h-0.5 w-1/2 
                                  ${selectedVehicle === 'car' ? 'bg-primary' : 
                                    selectedVehicle === 'bus' ? 'bg-blue-500' : 'bg-purple-500'}
                                  top-1/3 left-1/4 transform rotate-12
                                `}></div>

                                {/* Vehicle icon on the route */}
                                <div className="absolute top-1/3 left-1/3 transform -translate-x-1/2 -translate-y-1/2 z-20">
                                  <div className={`
                                    bg-white rounded-full p-1 shadow-sm
                                    ${selectedVehicle === 'car' ? 'text-primary' : 
                                      selectedVehicle === 'bus' ? 'text-blue-500' : 'text-purple-500'}
                                  `}>
                                    {selectedVehicle === 'car' ? (
                                      <Car className="h-4 w-4" />
                                    ) : selectedVehicle === 'bus' ? (
                                      <Bus className="h-4 w-4" />
                                    ) : (
                                      <Train className="h-4 w-4" />
                                    )}
                                  </div>
                                </div>
                              </>
                            )}
                          </div>
                          
                          {/* Map legend */}
                          <div className="absolute bottom-2 left-2 bg-white bg-opacity-90 rounded p-1 text-xs z-10">
                            <div className="flex items-center">
                              <div className="w-3 h-3 rounded-full bg-primary mr-1"></div>
                              <span>Rural location</span>
                            </div>
                            <div className="flex items-center mt-0.5">
                              <div className="w-3 h-3 rounded-full bg-secondary mr-1"></div>
                              <span>Urban location</span>
                            </div>
                          </div>

                          {/* Map controls */}
                          <div className="absolute bottom-4 right-4 z-10 flex flex-col space-y-2">
                            <Button 
                              variant="outline" 
                              size="icon" 
                              className="w-8 h-8 bg-white rounded-md shadow flex items-center justify-center text-primary"
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="outline" 
                              size="icon" 
                              className="w-8 h-8 bg-white rounded-md shadow flex items-center justify-center text-primary"
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        
                        {/* Show API key needed message when Google Maps failed to load */}
                        {status === 'error' && (
                          <div className="absolute bottom-2 w-full text-center text-xs text-amber-600 bg-amber-50 p-1 rounded">
                            Google Maps API key needed for full functionality
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
