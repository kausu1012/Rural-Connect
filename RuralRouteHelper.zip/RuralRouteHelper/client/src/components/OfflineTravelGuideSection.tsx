import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { getTravelGuides } from "@/lib/api";
import { TravelGuide } from "@/lib/types";

export default function OfflineTravelGuideSection() {
  const { data: travelGuides, isLoading, error } = useQuery({
    queryKey: ['/api/travel-guides'],
    queryFn: getTravelGuides
  });

  const handleDownloadGuides = () => {
    // In a real app, this would download guides for offline use
    // This would leverage browser caching, service workers, or localStorage
    alert("Travel guides are now available offline!");
  };

  if (isLoading) {
    return (
      <section className="py-10 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between mb-8">
            <h2 className="text-2xl md:text-3xl font-heading font-bold mb-4 md:mb-0">Offline Travel Guides</h2>
            <Button className="bg-accent hover:bg-accent-light text-white font-medium py-2 px-4 rounded-md transition duration-200 ease-in-out inline-flex items-center">
              <Download className="h-5 w-5 mr-1" />
              Download for Offline Use
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map(n => (
              <div key={n} className="bg-neutral-lightest rounded-lg shadow p-5 animate-pulse h-64">
                <div className="h-6 bg-gray-200 rounded w-1/2 mb-4"></div>
                <div className="h-4 bg-gray-200 rounded mb-6"></div>
                <div className="space-y-3 mb-4">
                  <div className="h-12 bg-gray-200 rounded"></div>
                  <div className="h-12 bg-gray-200 rounded"></div>
                  <div className="h-12 bg-gray-200 rounded"></div>
                </div>
                <div className="h-4 bg-gray-200 rounded w-1/3"></div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="py-10 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-heading font-bold text-center mb-8">Offline Travel Guides</h2>
          <div className="text-center text-red-500">
            Failed to load travel guides. Please try again later.
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-10 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between mb-8">
          <h2 className="text-2xl md:text-3xl font-heading font-bold mb-4 md:mb-0">Offline Travel Guides</h2>
          <Button 
            onClick={handleDownloadGuides}
            className="bg-accent hover:bg-accent-light text-white font-medium py-2 px-4 rounded-md transition duration-200 ease-in-out inline-flex items-center"
          >
            <Download className="h-5 w-5 mr-1" />
            Download for Offline Use
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {travelGuides?.map((guide: TravelGuide) => (
            <div key={guide.id} className="bg-neutral-lightest rounded-lg shadow overflow-hidden">
              <div className="p-5">
                <h3 className="text-xl font-heading font-semibold mb-2">{guide.title}</h3>
                <p className="text-neutral-dark text-sm mb-4">{guide.description}</p>
                <div className="space-y-3 mb-4">
                  {guide.highlights.map((highlight, idx) => (
                    <div key={idx} className="border-l-4 border-primary pl-3 py-1">
                      <div className="font-medium text-sm">{highlight}</div>
                      <div className="text-xs text-neutral-dark">
                        {idx === 0 && "Rural services often run on limited schedules with fewer trips per day."}
                        {idx === 1 && "Always call transit providers to confirm schedules during inclement weather."}
                        {idx === 2 && "Some rural services may not accept credit cards or mobile payments."}
                      </div>
                    </div>
                  ))}
                </div>
                <a href="#" className="text-primary font-medium text-sm inline-flex items-center">
                  View full guide
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                  </svg>
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
