import { ReactNode } from "react";
import Header from "./Header";
import Footer from "./Footer";
import ChatbotAssistant from "./ChatbotAssistant";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen bg-neutral-lightest text-neutral-darkest flex flex-col">
      <Header />
      <main className="flex-grow">{children}</main>
      <Footer />
      <ChatbotAssistant />
    </div>
  );
}
