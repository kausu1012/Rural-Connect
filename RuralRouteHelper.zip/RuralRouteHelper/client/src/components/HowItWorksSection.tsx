import { Step } from "@/lib/types";

export default function HowItWorksSection() {
  const steps: Step[] = [
    {
      number: 1,
      title: "Enter Locations",
      description: "Enter your starting point and destination, even if it's a remote area."
    },
    {
      number: 2,
      title: "View Options",
      description: "Browse available transportation methods and routes for your journey."
    },
    {
      number: 3,
      title: "Check Details",
      description: "Review schedules, costs, and travel times for each option."
    },
    {
      number: 4,
      title: "Save for Offline",
      description: "Download your travel plan for access without internet connection."
    }
  ];

  return (
    <section className="py-10 bg-neutral-lightest">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-heading font-bold text-center mb-8">
          How It Works
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {steps.map((step) => (
            <div key={step.number} className="flex flex-col items-center text-center">
              <div className="w-14 h-14 rounded-full bg-accent flex items-center justify-center text-white font-heading font-bold text-xl mb-3">
                {step.number}
              </div>
              <h3 className="font-heading font-semibold text-lg mb-2">{step.title}</h3>
              <p className="text-neutral-dark text-sm">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
