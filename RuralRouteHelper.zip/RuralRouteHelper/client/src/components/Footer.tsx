import { Link } from "wouter";
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Mail, 
  Phone, 
  MapPin 
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function Footer() {
  return (
    <footer className="bg-primary-dark text-white py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="font-heading font-bold text-lg mb-4">RuralConnect</h3>
            <p className="text-sm text-neutral-lightest mb-4">
              Connecting rural communities with reliable transportation options and travel information.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-neutral-lightest hover:text-white">
                <span className="sr-only">Facebook</span>
                <Facebook className="h-6 w-6" />
              </a>
              <a href="#" className="text-neutral-lightest hover:text-white">
                <span className="sr-only">Twitter</span>
                <Twitter className="h-6 w-6" />
              </a>
              <a href="#" className="text-neutral-lightest hover:text-white">
                <span className="sr-only">Instagram</span>
                <Instagram className="h-6 w-6" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-heading font-bold text-lg mb-4">Services</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/plan-trip">
                  <div className="text-neutral-lightest hover:text-white cursor-pointer">Route Planning</div>
                </Link>
              </li>
              <li>
                <Link href="/travel-guide">
                  <div className="text-neutral-lightest hover:text-white cursor-pointer">Transportation Options</div>
                </Link>
              </li>
              <li>
                <Link href="/resources">
                  <div className="text-neutral-lightest hover:text-white cursor-pointer">Rural Travel Guides</div>
                </Link>
              </li>
              <li>
                <Link href="/resources">
                  <div className="text-neutral-lightest hover:text-white cursor-pointer">Accessibility Information</div>
                </Link>
              </li>
              <li>
                <Link href="/resources">
                  <div className="text-neutral-lightest hover:text-white cursor-pointer">Travel Alerts</div>
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-heading font-bold text-lg mb-4">Resources</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/resources">
                  <div className="text-neutral-lightest hover:text-white cursor-pointer">Offline Maps</div>
                </Link>
              </li>
              <li>
                <Link href="/resources">
                  <div className="text-neutral-lightest hover:text-white cursor-pointer">Local Transportation Providers</div>
                </Link>
              </li>
              <li>
                <Link href="/resources">
                  <div className="text-neutral-lightest hover:text-white cursor-pointer">Community Transit Programs</div>
                </Link>
              </li>
              <li>
                <Link href="/resources">
                  <div className="text-neutral-lightest hover:text-white cursor-pointer">Rural Travel Tips</div>
                </Link>
              </li>
              <li>
                <Link href="/resources">
                  <div className="text-neutral-lightest hover:text-white cursor-pointer">FAQ</div>
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-heading font-bold text-lg mb-4">Get Updates</h3>
            <p className="text-sm text-neutral-lightest mb-3">
              Subscribe to receive low-data text updates on rural transportation.
            </p>
            <form className="space-y-2">
              <div>
                <Input 
                  type="tel" 
                  placeholder="Enter your phone number"
                  className="w-full px-3 py-2 border border-neutral-light bg-primary rounded-md focus:outline-none focus:ring-1 focus:ring-secondary text-white placeholder-neutral-light"
                />
              </div>
              <Button
                type="submit"
                className="w-full bg-secondary hover:bg-secondary-light text-white font-medium py-2 px-4 rounded-md transition duration-200 ease-in-out"
              >
                Subscribe
              </Button>
              <p className="text-xs text-neutral-light">
                Standard message rates apply. Reply STOP to unsubscribe.
              </p>
            </form>
          </div>
        </div>

        <div className="border-t border-accent pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-neutral-light mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} RuralConnect. All rights reserved.
          </p>
          <div className="flex space-x-6">
            <Link href="/privacy">
              <div className="text-sm text-neutral-light hover:text-white cursor-pointer">Privacy Policy</div>
            </Link>
            <Link href="/terms">
              <div className="text-sm text-neutral-light hover:text-white cursor-pointer">Terms of Service</div>
            </Link>
            <Link href="/accessibility">
              <div className="text-sm text-neutral-light hover:text-white cursor-pointer">Accessibility</div>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
