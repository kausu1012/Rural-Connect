import { useState, useRef, useEffect } from 'react';
import { Send, X, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Avatar } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

export default function ChatbotAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Hello! I\'m your RuralConnect assistant. How can I help you with rural transportation and travel safety today?',
      sender: 'bot',
      timestamp: new Date(),
    },
  ]);
  const [isMobile, setIsMobile] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Check if mobile
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    checkIfMobile();
    window.addEventListener('resize', checkIfMobile);
    return () => window.removeEventListener('resize', checkIfMobile);
  }, []);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Safety & security focused responses
  const getResponse = (userMessage: string): string => {
    const userMessageLower = userMessage.toLowerCase();
    
    // Safety related queries
    if (userMessageLower.includes('safe') || userMessageLower.includes('safety') || userMessageLower.includes('danger')) {
      return "Safety is our priority. Rural areas may have limited street lighting and cellular coverage. We recommend traveling during daylight hours when possible, informing someone of your travel plans, and keeping emergency contacts handy. Would you like specific safety tips for a particular route?";
    }
    
    // Security concerns
    else if (userMessageLower.includes('security') || userMessageLower.includes('theft') || userMessageLower.includes('stolen') || userMessageLower.includes('crime')) {
      return "We understand your security concerns. When traveling in unfamiliar areas, we recommend keeping valuables secure and out of sight, using registered transportation services, and staying aware of your surroundings. For more specific advice about a particular area, please share the location you're concerned about.";
    }
    
    // Emergency procedures
    else if (userMessageLower.includes('emergency') || userMessageLower.includes('accident') || userMessageLower.includes('help')) {
      return "In case of emergencies during rural travel, contact 112 (national emergency) or 108 (medical emergencies). Our app can help identify your GPS location to share with emergency services. Always keep a first aid kit and emergency supplies when traveling to remote areas. Would you like more emergency preparation tips?";
    }
    
    // Feedback handling
    else if (userMessageLower.includes('feedback') || userMessageLower.includes('suggest') || userMessageLower.includes('improve')) {
      return "Thank you for wanting to share feedback. Your insights help us improve our services and safety measures. Could you please elaborate on your experience or suggestions? We value specific details about routes, transportation providers, or features that could enhance rural travel safety.";
    }
    
    // Vehicle safety
    else if (userMessageLower.includes('vehicle') || userMessageLower.includes('bus') || userMessageLower.includes('car') || userMessageLower.includes('train')) {
      return "All transportation options in our network undergo regular safety inspections. For family travel, we recommend options with child safety features and adequate seating capacity. Would you like specific information about safety features for a particular transportation mode?";
    }
    
    // Weather and seasonal concerns
    else if (userMessageLower.includes('weather') || userMessageLower.includes('rain') || userMessageLower.includes('monsoon') || userMessageLower.includes('season')) {
      return "Weather conditions can significantly impact rural travel safety. During monsoon season (June-September), some rural roads may be affected by flooding or landslides. We provide real-time alerts for weather-related disruptions. Would you like to check current weather advisories for your route?";
    }
    
    // Accessibility
    else if (userMessageLower.includes('disable') || userMessageLower.includes('wheelchair') || userMessageLower.includes('accessibility') || userMessageLower.includes('special needs')) {
      return "We're committed to accessible travel for everyone. Our platform identifies transportation options with wheelchair accessibility, assistance services, and special accommodations. For specific accessibility requirements, please share details so we can recommend the most suitable options.";
    }
    
    // Default response for other queries
    else {
      return "I'm here to help with any rural transportation concerns, especially regarding safety and security. You can ask about safe travel routes, vehicle options for families, emergency procedures, accessibility features, or share feedback about your experience. How else can I assist you today?";
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      text: message,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setMessage('');

    // Simulate typing delay then add bot response
    setTimeout(() => {
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: getResponse(userMessage.text),
        sender: 'bot',
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, botMessage]);
    }, 1000);
  };

  const toggleChat = () => {
    setIsOpen(!isOpen);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <>
      {/* Chat Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={toggleChat}
          className={`${isOpen ? 'bg-neutral' : 'bg-primary'} text-white rounded-full p-4 shadow-lg`}
        >
          {isOpen ? <X size={24} /> : <MessageCircle size={24} />}
        </Button>
      </div>

      {/* Chat Panel */}
      {isOpen && (
        <div 
          className={`fixed ${isMobile ? 'inset-0 m-2' : 'bottom-20 right-6 w-96'} z-40 bg-white rounded-lg shadow-xl flex flex-col max-h-[80vh]`}
        >
          {/* Header */}
          <div className="bg-primary text-white p-4 rounded-t-lg flex justify-between items-center">
            <div className="flex items-center">
              <Avatar className="h-8 w-8 mr-2 border-2 border-white">
                <img src="https://randomuser.me/api/portraits/women/17.jpg" alt="Support agent" />
              </Avatar>
              <div>
                <h3 className="font-semibold">RuralConnect Support</h3>
                <div className="flex items-center">
                  <span className="h-2 w-2 bg-green-400 rounded-full mr-1"></span>
                  <span className="text-xs">Online</span>
                </div>
              </div>
            </div>
            <Badge variant="outline" className="bg-primary-dark text-white border-none">
              24/7 Support
            </Badge>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`${
                    msg.sender === 'user'
                      ? 'bg-primary text-white rounded-tl-lg rounded-tr-lg rounded-bl-lg'
                      : 'bg-gray-100 text-neutral-dark rounded-tl-lg rounded-tr-lg rounded-br-lg'
                  } p-3 max-w-[80%] shadow-sm`}
                >
                  <p>{msg.text}</p>
                  <p className={`text-xs mt-1 ${msg.sender === 'user' ? 'text-primary-lightest' : 'text-gray-500'}`}>
                    {formatTime(msg.timestamp)}
                  </p>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <form onSubmit={handleSubmit} className="border-t p-3 flex">
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type your message here..."
              className="flex-1 resize-none focus:outline-none focus:ring-1 focus:ring-primary"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSubmit(e);
                }
              }}
              rows={1}
            />
            <Button 
              type="submit" 
              disabled={!message.trim()}
              className="ml-2 bg-primary text-white"
            >
              <Send size={16} />
            </Button>
          </form>
        </div>
      )}
    </>
  );
}