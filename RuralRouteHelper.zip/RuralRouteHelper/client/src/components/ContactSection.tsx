import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Phone, MessageSquare, MapPin } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { submitContactForm } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const contactFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  subject: z.string().min(1, "Please select a subject"),
  message: z.string().min(10, "Message must be at least 10 characters"),
  requiresSms: z.boolean().default(false),
});

type ContactFormValues = z.infer<typeof contactFormSchema>;

export default function ContactSection() {
  const { toast } = useToast();

  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      email: "",
      subject: "",
      message: "",
      requiresSms: false,
    },
  });

  const mutation = useMutation({
    mutationFn: submitContactForm,
    onSuccess: () => {
      toast({
        title: "Message sent!",
        description: "We'll get back to you as soon as possible.",
        variant: "default",
      });
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error sending message",
        description: "Please try again later or contact us by phone.",
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: ContactFormValues) => {
    mutation.mutate(data);
  };

  return (
    <section className="py-10 bg-neutral-lightest">
      <div className="container mx-auto px-4">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-2xl md:text-3xl font-heading font-bold text-center mb-6">Need Help with Rural Travel?</h2>
          
          <div className="flex flex-col md:flex-row md:space-x-8">
            <div className="md:w-1/2 mb-6 md:mb-0">
              <h3 className="text-xl font-heading font-semibold mb-4">Contact Us</h3>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="block text-neutral-dark text-sm font-medium mb-1">Name</FormLabel>
                          <FormControl>
                            <Input 
                              {...field} 
                              className="w-full px-3 py-2 border border-neutral-light rounded-md focus:outline-none focus:ring-1 focus:ring-primary"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="block text-neutral-dark text-sm font-medium mb-1">Email</FormLabel>
                          <FormControl>
                            <Input 
                              type="email" 
                              {...field} 
                              className="w-full px-3 py-2 border border-neutral-light rounded-md focus:outline-none focus:ring-1 focus:ring-primary"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="subject"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="block text-neutral-dark text-sm font-medium mb-1">Subject</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="w-full px-3 py-2 border border-neutral-light rounded-md focus:outline-none focus:ring-1 focus:ring-primary">
                              <SelectValue placeholder="Select an option" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="route">Route Information</SelectItem>
                            <SelectItem value="schedule">Schedule Inquiry</SelectItem>
                            <SelectItem value="accessibility">Accessibility Needs</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="block text-neutral-dark text-sm font-medium mb-1">Message</FormLabel>
                        <FormControl>
                          <Textarea 
                            rows={4} 
                            {...field} 
                            className="w-full px-3 py-2 border border-neutral-light rounded-md focus:outline-none focus:ring-1 focus:ring-primary"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="requiresSms"
                    render={({ field }) => (
                      <FormItem className="flex items-center space-x-2">
                        <FormControl>
                          <Checkbox 
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            className="h-4 w-4 text-primary border-neutral-light rounded focus:ring-primary"
                          />
                        </FormControl>
                        <FormLabel className="text-sm text-neutral-dark">
                          I may have limited connectivity. Send an SMS response if possible.
                        </FormLabel>
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit"
                    disabled={mutation.isPending}
                    className="w-full bg-secondary hover:bg-secondary-light text-white font-medium py-2 px-4 rounded-md transition duration-200 ease-in-out"
                  >
                    {mutation.isPending ? "Sending..." : "Send Message"}
                  </Button>
                </form>
              </Form>
            </div>
            
            <div className="md:w-1/2">
              <h3 className="text-xl font-heading font-semibold mb-4">Other Ways to Reach Us</h3>
              
              <div className="space-y-4">
                <div className="p-4 bg-neutral-lightest rounded-md border border-neutral-light">
                  <h4 className="font-heading font-semibold mb-2">Phone Support</h4>
                  <p className="text-neutral-dark text-sm mb-2">Our phone lines are open for areas with limited internet connectivity.</p>
                  <div className="flex items-center">
                    <Phone className="h-5 w-5 text-primary mr-2" />
                    <span className="font-medium">1-800-RURALCONNECT</span>
                  </div>
                </div>
                
                <div className="p-4 bg-neutral-lightest rounded-md border border-neutral-light">
                  <h4 className="font-heading font-semibold mb-2">SMS Support</h4>
                  <p className="text-neutral-dark text-sm mb-2">Text-based support for basic inquiries and schedule updates.</p>
                  <div className="flex items-center">
                    <MessageSquare className="h-5 w-5 text-primary mr-2" />
                    <span className="font-medium">Text "HELP" to 87611</span>
                  </div>
                </div>
                
                <div className="p-4 bg-neutral-lightest rounded-md border border-neutral-light">
                  <h4 className="font-heading font-semibold mb-2">Local Offices</h4>
                  <p className="text-neutral-dark text-sm mb-2">In-person assistance is available at our regional offices.</p>
                  <a href="#" className="text-primary font-medium text-sm inline-flex items-center">
                    Find a location near you
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                    </svg>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
