import { useState, useEffect } from 'react';

type MapStatus = 'loading' | 'ready' | 'error' | 'not-initialized';

interface UseGoogleMapsOptions {
  apiKey?: string;
  callback?: string;
  libraries?: string[];
  version?: string;
  autoload?: boolean;
}

export function useGoogleMaps({
  apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY,
  callback = 'initMap',
  libraries = [],
  version = 'weekly',
  autoload = true,
}: UseGoogleMapsOptions = {}) {
  const [status, setStatus] = useState<MapStatus>('not-initialized');
  
  useEffect(() => {
    if (!autoload) return;
    
    // Check if API key is available
    if (!apiKey) {
      console.warn('Google Maps API key is missing. Map functionality will be limited.');
      setStatus('error');
      return;
    }
    
    // If Google Maps is already loaded
    if (window.google && window.google.maps) {
      setStatus('ready');
      return;
    }
    
    setStatus('loading');
    
    // Create the script element
    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&callback=${callback}&v=${version}${
      libraries.length ? `&libraries=${libraries.join(',')}` : ''
    }`;
    script.async = true;
    script.defer = true;
    
    // Set global callback
    window[callback] = () => {
      setStatus('ready');
      // Clean up
      delete window[callback];
    };
    
    // Handle errors
    script.onerror = () => {
      setStatus('error');
      console.error('Error loading Google Maps API');
    };
    
    // Append script to head
    document.head.appendChild(script);
    
    return () => {
      // Clean up script on unmount
      if (document.head.contains(script)) {
        document.head.removeChild(script);
      }
    };
  }, [apiKey, callback, libraries, version, autoload]);
  
  const loadGoogleMapsScript = () => {
    if (status === 'not-initialized') {
      setStatus('loading');
      // Create the script element
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&callback=${callback}&v=${version}${
        libraries.length ? `&libraries=${libraries.join(',')}` : ''
      }`;
      script.async = true;
      script.defer = true;
      
      // Set global callback
      window[callback] = () => {
        setStatus('ready');
        // Clean up
        delete window[callback];
      };
      
      // Handle errors
      script.onerror = () => {
        setStatus('error');
        console.error('Error loading Google Maps API');
      };
      
      // Append script to head
      document.head.appendChild(script);
    }
  };
  
  return { status, isLoaded: status === 'ready', loadGoogleMapsScript };
}

// Add needed global types
declare global {
  interface Window {
    [key: string]: any;
    google: any;
  }
}