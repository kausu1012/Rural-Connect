import { apiRequest } from "./queryClient";
import type { 
  SearchParams, 
  RouteInfo,
  ContactFormData
} from "./types";

// Location related API calls
export const searchLocations = async (query: string) => {
  const response = await fetch(`/api/locations/search?q=${encodeURIComponent(query)}`);
  if (!response.ok) {
    throw new Error('Failed to search locations');
  }
  return await response.json();
};

export const getAllLocations = async () => {
  const response = await fetch('/api/locations');
  if (!response.ok) {
    throw new Error('Failed to fetch locations');
  }
  return await response.json();
};

// Transport options related API calls
export const getTransportOptions = async () => {
  const response = await fetch('/api/transport-options');
  if (!response.ok) {
    throw new Error('Failed to fetch transport options');
  }
  return await response.json();
};

// Routes related API calls
export const searchRoutes = async (params: SearchParams): Promise<RouteInfo[]> => {
  const queryParams = new URLSearchParams({
    from: params.departure,
    to: params.arrival,
    date: params.date,
  });

  const response = await fetch(`/api/search-routes?${queryParams.toString()}`);
  
  if (!response.ok) {
    throw new Error('Failed to search routes');
  }
  
  return await response.json();
};

export const getPopularRoutes = async (): Promise<RouteInfo[]> => {
  const response = await fetch('/api/routes/popular');
  
  if (!response.ok) {
    throw new Error('Failed to fetch popular routes');
  }
  
  const routes = await response.json();
  
  // Get additional information for each route
  const routesWithDetails = await Promise.all(routes.map(async (route: any) => {
    const [fromLocation, toLocation, transportOption] = await Promise.all([
      fetch(`/api/locations/${route.fromLocationId}`).then(res => res.json()),
      fetch(`/api/locations/${route.toLocationId}`).then(res => res.json()),
      fetch(`/api/transport-options/${route.transportOptionId}`).then(res => res.json()),
    ]);
    
    return {
      ...route,
      fromLocation,
      toLocation,
      transportOption,
    };
  }));
  
  return routesWithDetails;
};

// Travel guides related API calls
export const getTravelGuides = async () => {
  const response = await fetch('/api/travel-guides');
  if (!response.ok) {
    throw new Error('Failed to fetch travel guides');
  }
  return await response.json();
};

// Inquiries (contact form) related API calls
export const submitContactForm = async (formData: ContactFormData) => {
  const response = await apiRequest('POST', '/api/inquiries', formData);
  return await response.json();
};
