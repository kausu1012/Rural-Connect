import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format a duration in minutes to a readable format
export function formatDuration(minutes: number): string {
  if (minutes < 60) {
    return `${minutes} min`;
  }
  
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  
  if (remainingMinutes === 0) {
    return `${hours} hr`;
  }
  
  return `${hours} hr ${remainingMinutes} min`;
}

// Format a price in cents to a readable format with currency symbol
export function formatPrice(cents: number | undefined): string {
  if (cents === undefined) {
    return "Price unavailable";
  }
  
  const dollars = cents / 100;
  return `$${dollars.toFixed(2)}`;
}

// Format a date string to a readable format
export function formatDate(dateString: string): string {
  const date = new Date(dateString);
  
  if (isNaN(date.getTime())) {
    return "Invalid date";
  }
  
  return date.toLocaleDateString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
    year: "numeric"
  });
}

// Get icon name for transport type
export function getTransportIcon(type: string): string {
  switch (type.toLowerCase()) {
    case "bus":
      return "bus";
    case "train":
      return "train";
    case "shuttle":
    case "van":
      return "truck";
    case "carpool":
    case "rideshare":
      return "users";
    case "taxi":
      return "taxi";
    default:
      return "map";
  }
}

// Calculate estimated arrival time from departure time and duration
export function calculateArrivalTime(departureTime: string, durationMinutes: number): string {
  try {
    const departure = new Date(`1970-01-01T${departureTime}`);
    departure.setMinutes(departure.getMinutes() + durationMinutes);
    
    return departure.toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true
    });
  } catch (error) {
    return "Time unavailable";
  }
}
