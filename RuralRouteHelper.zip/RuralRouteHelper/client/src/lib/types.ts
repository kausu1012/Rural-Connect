// Frontend type definitions

export interface SearchParams {
  departure: string;
  arrival: string;
  date: string;
  passengers: number;
}

export interface Feature {
  icon: string;
  title: string;
  description: string;
}

export interface Step {
  number: number;
  title: string;
  description: string;
}

export interface TransportOption {
  icon: string;
  title: string;
  description: string;
  features: string[];
}

export interface RouteInfo {
  id: number;
  fromLocation: {
    id: number;
    name: string;
  };
  toLocation: {
    id: number;
    name: string;
  };
  transportOption: {
    id: number;
    name: string;
    type: string;
  };
  duration: number;
  price: number;
  schedule: string;
  date: string;
}

export interface TravelGuide {
  id: number;
  title: string;
  description: string;
  highlights: string[];
}

export interface ContactFormData {
  name: string;
  email: string;
  subject: string;
  message: string;
  requiresSms: boolean;
}
