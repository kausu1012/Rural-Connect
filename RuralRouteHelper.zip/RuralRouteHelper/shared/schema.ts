import { pgTable, text, serial, integer, timestamp, boolean, json, numeric, pgEnum, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums for typed data
export const locationTypeEnum = pgEnum('location_type', ['rural', 'urban', 'suburban', 'remote']);
export const transportTypeEnum = pgEnum('transport_type', ['bus', 'train', 'car', 'taxi', 'auto', 'bike', 'walking']);
export const guideTypeEnum = pgEnum('guide_type', ['general', 'seasonal', 'travel_tips', 'emergency', 'local_culture']);

// User schema for authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  fullName: text("full_name"),
  phone: text("phone"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  fullName: true,
  phone: true,
});

// Location schema for storing location data
export const locations = pgTable("locations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: locationTypeEnum("type").notNull(), // rural, urban, etc
  description: text("description"),
  latitude: real("latitude"),
  longitude: real("longitude"),
  region: text("region"),
  district: text("district"),
  state: text("state"),
  population: integer("population"),
  amenities: json("amenities").$type<string[]>().default([]),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertLocationSchema = createInsertSchema(locations).pick({
  name: true,
  type: true,
  description: true,
  latitude: true,
  longitude: true,
  region: true,
  district: true,
  state: true,
  population: true,
  amenities: true,
});

// Transport options schema
export const transportOptions = pgTable("transport_options", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: transportTypeEnum("type").notNull(), // bus, train, etc.
  description: text("description"),
  iconName: text("icon_name"),
  features: json("features").$type<string[]>().default([]),
  capacity: integer("capacity"), // passenger capacity
  accessibility: boolean("accessibility").default(false), // wheelchair accessible?
  costPerKm: numeric("cost_per_km", { precision: 10, scale: 2 }),
  operator: text("operator"), // transport company
  contactInfo: text("contact_info"), // booking contact
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTransportOptionSchema = createInsertSchema(transportOptions).pick({
  name: true,
  type: true,
  description: true,
  iconName: true,
  features: true,
  capacity: true,
  accessibility: true,
  costPerKm: true,
  operator: true,
  contactInfo: true,
});

// Routes schema with foreign key references
export const routes = pgTable("routes", {
  id: serial("id").primaryKey(),
  fromLocationId: integer("from_location_id").notNull().references(() => locations.id),
  toLocationId: integer("to_location_id").notNull().references(() => locations.id),
  transportOptionId: integer("transport_option_id").notNull().references(() => transportOptions.id),
  duration: integer("duration").notNull(), // in minutes
  distance: numeric("distance", { precision: 10, scale: 2 }), // in km
  price: numeric("price", { precision: 10, scale: 2 }), // in currency
  schedule: text("schedule"), // departure times
  frequency: text("frequency"), // daily, weekends only, etc.
  isPopular: boolean("is_popular").default(false),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertRouteSchema = createInsertSchema(routes).pick({
  fromLocationId: true,
  toLocationId: true,
  transportOptionId: true,
  duration: true,
  distance: true,
  price: true,
  schedule: true,
  frequency: true,
  isPopular: true,
  isActive: true,
});

// Travel guides schema
export const travelGuides = pgTable("travel_guides", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  content: text("content").notNull(),
  type: guideTypeEnum("type").default('general').notNull(),
  highlights: json("highlights").$type<string[]>().default([]),
  author: text("author"),
  locationId: integer("location_id").references(() => locations.id), // optional reference to specific location
  imageUrl: text("image_url"),
  publishedAt: timestamp("published_at").defaultNow(),
});

export const insertTravelGuideSchema = createInsertSchema(travelGuides).pick({
  title: true,
  description: true,
  content: true,
  type: true,
  highlights: true,
  author: true,
  locationId: true,
  imageUrl: true,
});

// Inquiries schema for contact form
export const inquiries = pgTable("inquiries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  phone: text("phone"),
  requiresSms: boolean("requires_sms").default(false),
  status: text("status").default("new"), // new, in-progress, completed
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertInquirySchema = createInsertSchema(inquiries).pick({
  name: true,
  email: true,
  subject: true,
  message: true,
  phone: true,
  requiresSms: true,
});

// Reviews for routes or locations
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  routeId: integer("route_id").references(() => routes.id),
  locationId: integer("location_id").references(() => locations.id),
  rating: integer("rating").notNull(), // 1-5 stars
  title: text("title"),
  comment: text("comment"),
  dateOfTravel: timestamp("date_of_travel"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertReviewSchema = createInsertSchema(reviews).pick({
  userId: true,
  routeId: true,
  locationId: true,
  rating: true,
  title: true,
  comment: true,
  dateOfTravel: true,
});

// Define the zod type for use in the frontend
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertLocation = z.infer<typeof insertLocationSchema>;
export type Location = typeof locations.$inferSelect;

export type InsertTransportOption = z.infer<typeof insertTransportOptionSchema>;
export type TransportOption = typeof transportOptions.$inferSelect;

export type InsertRoute = z.infer<typeof insertRouteSchema>;
export type Route = typeof routes.$inferSelect;

export type InsertTravelGuide = z.infer<typeof insertTravelGuideSchema>;
export type TravelGuide = typeof travelGuides.$inferSelect;

export type InsertInquiry = z.infer<typeof insertInquirySchema>;
export type Inquiry = typeof inquiries.$inferSelect;

export type InsertReview = z.infer<typeof insertReviewSchema>;
export type Review = typeof reviews.$inferSelect;
